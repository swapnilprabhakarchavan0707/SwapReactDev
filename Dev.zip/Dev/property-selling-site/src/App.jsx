import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import ProtectedRoute from './components/ProtectedRoute';

// Public pages
import Home from './pages/Home';
import About from './pages/About';
import Contact from './pages/Contact';
import Services from './pages/Services';
import Listings from './pages/Listings';
import PropertyDetails from './pages/PropertyDetails';
import Login from './pages/Login';
import Register from './pages/Register';

// Buyer pages
import BuyerDashboard from './pages/buyer/BuyerDashboard';
import PurchaseProperty from './pages/buyer/PurchaseProperty';
import DisplayStatus from './pages/buyer/DisplayStatus';
import TransactionHistory from './pages/buyer/TransactionHistory';
import BuyerMessages from './pages/buyer/SellerDetails';

// Seller pages
import SellerDashboard from './pages/seller/SellerDashboard';
import MyProperties from './pages/seller/MyProperties';
import AddProperty from './pages/seller/AddProperty';
import EditProperty from './pages/seller/EditProperty';
import BankDetails from './pages/seller/BankDetails';
import AddBankDetail from './pages/seller/AddBankDetail'; 
import EditBankDetail from './pages/seller/EditBankDetail';
import GenerateBill from './pages/seller/GenerateBill';
import TransactionRecord from './pages/seller/TransactionRecord';
import ContactDetails from './pages/seller/ContactDetails';

// Admin pages
import AdminDashboard from './pages/admin/AdminDashboard';
import ManageAdmin from './pages/admin/ManageAdmin';
import ManageSellers from './pages/admin/ManageSellers';
import ManageBuyers from './pages/admin/ManageBuyers';
import ManageProperties from './pages/admin/ManageProperties';
import ManageTransactions from './pages/admin/ManageTransactions'; // Centralized Hub
import Reviews from './pages/admin/Reviews';
import AdminMessages from './pages/admin/Messages';

function App() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow">
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/services" element={<Services />} />
          <Route path="/listings" element={<Listings />} />
          <Route path="/property/:id" element={<PropertyDetails />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />

          {/* Buyer Routes */}
          <Route path="/buyer/dashboard" element={<ProtectedRoute allowedRoles={['buyer']}><BuyerDashboard /></ProtectedRoute>} />
          <Route path="/buyer/status" element={<ProtectedRoute allowedRoles={['buyer']}><DisplayStatus /></ProtectedRoute>} />
          <Route path="/buyer/transactions" element={<ProtectedRoute allowedRoles={['buyer']}><TransactionHistory /></ProtectedRoute>} />
          <Route path="/buyer/messages" element={<ProtectedRoute allowedRoles={['buyer']}><BuyerMessages /></ProtectedRoute>} />
          <Route path="/buyer/purchase/:id" element={<ProtectedRoute allowedRoles={['buyer']}><PurchaseProperty /></ProtectedRoute>} />
          
          {/* Seller Routes */}
          <Route path="/seller/dashboard" element={<ProtectedRoute allowedRoles={['seller']}><SellerDashboard /></ProtectedRoute>} />
          <Route path="/seller/properties" element={<ProtectedRoute allowedRoles={['seller']}><MyProperties /></ProtectedRoute>} />
          <Route path="/seller/add-property" element={<ProtectedRoute allowedRoles={['seller']}><AddProperty /></ProtectedRoute>} />
          <Route path="/seller/edit-property/:id" element={<ProtectedRoute allowedRoles={['seller']}><EditProperty /></ProtectedRoute>} />
          <Route path="/seller/generate-bill" element={<ProtectedRoute allowedRoles={['seller']}><GenerateBill /></ProtectedRoute>} />
          <Route path="/seller/transactions" element={<ProtectedRoute allowedRoles={['seller']}><TransactionRecord /></ProtectedRoute>} />
          <Route path="/seller/contacts" element={<ProtectedRoute allowedRoles={['seller']}><ContactDetails /></ProtectedRoute>} />
          <Route path="/seller/bank-details" element={<ProtectedRoute allowedRoles={['seller']}><BankDetails /></ProtectedRoute>} />
          <Route path="/seller/add-bank" element={<ProtectedRoute allowedRoles={['seller']}><AddBankDetail /></ProtectedRoute>} />
          <Route path="/seller/edit-bank/:id" element={<ProtectedRoute allowedRoles={['seller']}><EditBankDetail /></ProtectedRoute>} />

          {/* Admin Routes */}
          <Route path="/admin/dashboard" element={<ProtectedRoute allowedRoles={['admin']}><AdminDashboard /></ProtectedRoute>} />
          <Route path="/admin/manage" element={<ProtectedRoute allowedRoles={['admin']}><ManageAdmin /></ProtectedRoute>} />
          <Route path="/admin/sellers" element={<ProtectedRoute allowedRoles={['admin']}><ManageSellers /></ProtectedRoute>} />
          <Route path="/admin/buyers" element={<ProtectedRoute allowedRoles={['admin']}><ManageBuyers /></ProtectedRoute>} />
          <Route path="/admin/properties" element={<ProtectedRoute allowedRoles={['admin']}><ManageProperties /></ProtectedRoute>} />
          
          {/* Main Transaction Management Hub: 
              Handles "Generate Bill" flow, Admin's own sales, 
              Global seller records, and Bank/Account details.
          */}
          <Route path="/admin/transactions" element={<ProtectedRoute allowedRoles={['admin']}><ManageTransactions /></ProtectedRoute>} />
          <Route path="/admin/reviews" element={<ProtectedRoute allowedRoles={['admin']}><Reviews /></ProtectedRoute>} />
          <Route path="/admin/messages" element={<ProtectedRoute allowedRoles={['admin']}><AdminMessages /></ProtectedRoute>} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}

export default App;