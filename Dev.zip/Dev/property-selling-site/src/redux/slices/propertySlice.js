import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../services/api';

export const fetchProperties = createAsyncThunk('property/fetchProperties', async (filters = {}, { rejectWithValue }) => {
  try {
    const cleanFilters = {};
    Object.keys(filters).forEach(key => {
      if (filters[key] !== '' && filters[key] !== null && filters[key] !== undefined) {
        cleanFilters[key] = filters[key];
      }
    });
    const response = await api.get('/properties', { params: cleanFilters });
    return response.data.properties;
  } catch (error) {
    return rejectWithValue(error.response?.data || { message: 'Failed to fetch properties' });
  }
});

export const fetchPropertyById = createAsyncThunk('property/fetchPropertyById', async (id, { rejectWithValue }) => {
  try {
    const response = await api.get(`/properties/${id}`);
    return response.data;
  } catch (error) {
    return rejectWithValue(error.response?.data || { message: 'Failed to fetch property' });
  }
});

export const addProperty = createAsyncThunk('property/addProperty', async (formData, { rejectWithValue }) => {
  try {
    const response = await api.post('/properties', formData, { headers: { 'Content-Type': 'multipart/form-data' } });
    return response.data;
  } catch (error) {
    return rejectWithValue(error.response?.data || { message: 'Failed to add property' });
  }
});

export const updateProperty = createAsyncThunk('property/updateProperty', async ({ id, formData }, { rejectWithValue }) => {
  try {
    const response = await api.put(`/properties/${id}`, formData, { headers: { 'Content-Type': 'multipart/form-data' } });
    return response.data;
  } catch (error) {
    return rejectWithValue(error.response?.data || { message: 'Failed to update property' });
  }
});

export const deleteProperty = createAsyncThunk('property/deleteProperty', async (id, { rejectWithValue }) => {
  try {
    await api.delete(`/properties/${id}`);
    return id;
  } catch (error) {
    return rejectWithValue(error.response?.data || { message: 'Failed to delete property' });
  }
});

const propertySlice = createSlice({
  name: 'property',
  initialState: { 
    properties: [], 
    selectedProperty: null, 
    loading: false, 
    error: null, 
    currentFilters: {} 
  },
  reducers: {
    clearSelectedProperty: (state) => { 
      state.selectedProperty = null; 
      state.error = null;
    },
    clearError: (state) => { state.error = null; },
  },
  extraReducers: (builder) => {
    builder
      // Fetch All Properties
      .addCase(fetchProperties.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchProperties.fulfilled, (state, action) => {
        state.loading = false; 
        state.properties = action.payload || [];
      })
      .addCase(fetchProperties.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      // Fetch Single Property
      .addCase(fetchPropertyById.pending, (state) => {
        state.loading = true;
        state.error = null;
        // NECESSARY CHANGE: Clear previous selection on start to avoid UI flicker
        state.selectedProperty = null; 
      })
      .addCase(fetchPropertyById.fulfilled, (state, action) => {
        state.loading = false;
        state.selectedProperty = action.payload;
      })
      .addCase(fetchPropertyById.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
        state.selectedProperty = null;
      })
      // Delete Property
      .addCase(deleteProperty.fulfilled, (state, action) => {
        state.properties = Array.isArray(state.properties) 
          ? state.properties.filter(p => p.property_id !== action.payload)
          : [];
      });
  },
});

export const { clearSelectedProperty, clearError } = propertySlice.actions;
export default propertySlice.reducer;