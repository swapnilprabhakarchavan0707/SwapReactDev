import { useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { fetchPropertyById, clearSelectedProperty } from '../redux/slices/propertySlice';
import { toast } from 'react-toastify';

const propertyImagesFallback = [
  'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=900',
  'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=900',
  'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=900',
];

const PropertyDetails = () => {
  const { id } = useParams();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  
  const { selectedProperty, loading, error } = useSelector((state) => state.property);
  const { isAuthenticated, user } = useSelector((state) => state.auth);

  useEffect(() => {
    dispatch(clearSelectedProperty());
    dispatch(fetchPropertyById(id));
  }, [dispatch, id]);

  const handleBuyNow = () => {
    if (!isAuthenticated) {
      toast.error('Please login to proceed with the purchase');
      navigate('/login');
      return;
    }

    // NECESSARY CHANGE: Prefer the ID from the Redux object to ensure data consistency
    // This matches the key 'property_id' returned by your SQL query in bankController.js
    const propertyId = selectedProperty?.property?.property_id || id;

    if (!propertyId) {
      toast.error('Property ID missing. Please refresh and try again.');
      return;
    }

    // Redirect to purchase page using the confirmed ID
    navigate(`/buyer/purchase/${propertyId}`);
  };

  // Loading State
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="text-center">
          <div className="text-6xl mb-4 animate-bounce">⏳</div>
          <p className="text-xl text-gray-600 font-medium">Loading property details...</p>
        </div>
      </div>
    );
  }

  // Error State
  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="text-center p-8">
          <p className="text-xl text-red-500 font-medium">Error: {error.message || 'Failed to load property'}</p>
          <Link to="/listings" className="mt-4 text-blue-600 underline">Back to Listings</Link>
        </div>
      </div>
    );
  }

  // Check if data is missing
  if (!selectedProperty || !selectedProperty.property) {
    return null; 
  }

  const { property, reviews, images } = selectedProperty;
  
  const mainImage = images && images.length > 0 
    ? `http://localhost:5000${images[0].image_url}` 
    : propertyImagesFallback[property.property_id % propertyImagesFallback.length];

  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center text-sm text-gray-600">
            <Link to="/" className="hover:text-blue-600">Home</Link>
            <span className="mx-2">/</span>
            <Link to="/listings" className="hover:text-blue-600">Listings</Link>
            <span className="mx-2">/</span>
            <span className="text-gray-800 font-semibold">{property.title}</span>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
              <div className="relative h-[500px]">
                <img
                  src={mainImage}
                  alt={property.title}
                  className="w-full h-full object-cover"
                  onError={(e) => { e.target.src = propertyImagesFallback[0]; }}
                />
                <div className="absolute top-4 right-4 bg-blue-600 text-white px-6 py-3 rounded-full font-bold text-lg shadow-lg">
                  {property.property_type}
                </div>
                <div className="absolute top-4 left-4 bg-green-600 text-white px-6 py-3 rounded-full font-bold text-lg shadow-lg capitalize">
                  {property.status}
                </div>
              </div>
              
              {images && images.length > 1 && (
                <div className="flex gap-2 p-4 bg-gray-100 overflow-x-auto">
                   {images.map((img, idx) => (
                     <img 
                        key={idx} 
                        src={`http://localhost:5000${img.image_url}`} 
                        className="h-20 w-32 object-cover rounded-lg cursor-pointer hover:opacity-80 border-2 border-transparent hover:border-blue-500" 
                        alt="gallery" 
                        onClick={(e) => {
                          document.querySelector('.relative.h-\\[500px\\] img').src = e.target.src;
                        }}
                      />
                   ))}
                </div>
              )}
            </div>

            <div className="bg-white rounded-2xl shadow-xl p-8">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h1 className="text-4xl font-bold text-gray-800 mb-2">{property.title}</h1>
                  <p className="text-xl text-gray-600 flex items-center">
                    <span className="mr-2">📍</span>
                    {property.address}, {property.city}
                  </p>
                </div>
              </div>

              <div className="mb-8">
                <p className="text-5xl font-bold text-blue-600 mb-2">
                  ₹{Number(property.price).toLocaleString()}
                </p>
                <span className="inline-block bg-blue-100 text-blue-800 px-6 py-2 rounded-full font-bold text-lg">
                  {property.property_type}
                </span>
              </div>

              <div className="border-t pt-6">
                <h2 className="text-2xl font-bold text-gray-800 mb-4">Description</h2>
                <p className="text-gray-700 leading-relaxed text-lg">
                  {property.description || 'No description provided.'}
                </p>
              </div>

              <div className="border-t pt-6 mt-6">
                <h2 className="text-2xl font-bold text-gray-800 mb-4">Property Features</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div className="bg-blue-50 p-4 rounded-xl">
                    <p className="text-gray-600 text-sm mb-1">Type</p>
                    <p className="font-bold text-gray-800">{property.property_type}</p>
                  </div>
                  <div className="bg-green-50 p-4 rounded-xl">
                    <p className="text-gray-600 text-sm mb-1">Status</p>
                    <p className="font-bold text-gray-800 capitalize">{property.status}</p>
                  </div>
                  <div className="bg-purple-50 p-4 rounded-xl">
                    <p className="text-gray-600 text-sm mb-1">Location</p>
                    <p className="font-bold text-gray-800">{property.city}</p>
                  </div>
                </div>
              </div>
            </div>

            {reviews && reviews.length > 0 && (
              <div className="bg-white rounded-2xl shadow-xl p-8">
                <h2 className="text-2xl font-bold text-gray-800 mb-6">Customer Reviews</h2>
                <div className="space-y-4">
                  {reviews.map((review) => (
                    <div key={review.review_id} className="border-b pb-4 last:border-b-0">
                      <div className="flex items-center mb-2">
                        <span className="font-bold text-gray-800 mr-2">{review.buyer_name}</span>
                        <span className="text-yellow-500">{'⭐'.repeat(review.rating)}</span>
                      </div>
                      <p className="text-gray-700">{review.comment}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="space-y-6">
            <div className="bg-white rounded-2xl shadow-xl p-6 sticky top-4">
              <h3 className="text-2xl font-bold text-gray-800 mb-6">Interested?</h3>
              
              {/* Buyer View */}
              {isAuthenticated && user?.role === 'buyer' ? (
                <div className="space-y-4">
                  <button onClick={handleBuyNow} className="w-full bg-gradient-to-r from-pink-500 to-red-500 text-white py-4 rounded-xl hover:from-pink-600 hover:to-red-600 font-bold text-lg transition shadow-lg">
                    💎 Buy Now
                  </button>
                  <Link to="/contact" className="block w-full bg-gradient-to-r from-green-500 to-green-600 text-white py-4 rounded-xl hover:from-green-600 hover:to-green-700 font-bold text-lg transition text-center shadow-lg">
                    📞 Contact
                  </Link>
                </div>
              ) : isAuthenticated && user?.role === 'seller' ? (
                /* Seller View */
                <div className="p-4 bg-gray-50 border border-gray-200 rounded-xl text-center">
                  <p className="text-gray-600 font-medium italic">Sellers cannot purchase properties.</p>
                </div>
              ) : (
                /* Guest View */
                <Link to="/login" className="block w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white py-4 rounded-xl hover:from-blue-700 hover:to-blue-800 font-bold text-lg transition text-center shadow-lg">
                  Login to Proceed
                </Link>
              )}

              <div className="mt-8 pt-6 border-t">
                <h4 className="font-bold text-gray-800 mb-4 text-lg">Seller Information</h4>
                <div className="space-y-3">
                  <div className="flex items-start">
                    <span className="text-gray-600 w-20">Name:</span>
                    <span className="font-semibold text-gray-800">{property.seller_name}</span>
                  </div>
                  <div className="flex items-start">
                    <span className="text-gray-600 w-20">Email:</span>
                    <span className="font-semibold text-gray-800 text-sm break-all">{property.seller_email}</span>
                  </div>
                  {property.seller_phone && (
                    <div className="flex items-start">
                      <span className="text-gray-600 w-20">Phone:</span>
                      <span className="font-semibold text-gray-800">{property.seller_phone}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropertyDetails;