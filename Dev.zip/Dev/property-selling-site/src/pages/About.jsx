const About = () => {
  return (
    <div className="bg-gray-50">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-slate-700 via-slate-600 to-slate-800 text-white py-24">
        <div className="absolute inset-0 bg-black opacity-20"></div>
        <div className="container mx-auto px-4 text-center relative z-10">
          <h1 className="text-6xl font-bold mb-4">About PropertyHub</h1>
          <p className="text-2xl text-gray-200">Your trusted partner in finding the perfect property</p>
        </div>
      </div>

      {/* Mission Section */}
      <div className="container mx-auto px-4 py-20">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-2xl shadow-xl p-12 mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-6 text-center">
              Why Shop With Us? Your Perfect Property Destination!
            </h2>
            <p className="text-lg text-gray-700 leading-relaxed mb-8">
              At PropertyHub, we believe finding a property should be more than just a transaction. It should be an experience! 
              Here's why you should choose us for all your real estate needs:
            </p>

            <div className="space-y-8">
              <div className="border-l-4 border-blue-600 pl-6">
                <h3 className="text-2xl font-bold text-gray-800 mb-3">Our Mission</h3>
                <p className="text-gray-700 leading-relaxed">
                  To provide a transparent, secure, and efficient platform for property transactions, making your dream home accessible and affordable.
                </p>
              </div>

              <div className="border-l-4 border-green-600 pl-6">
                <h3 className="text-2xl font-bold text-gray-800 mb-3">Our Vision</h3>
                <p className="text-gray-700 leading-relaxed">
                  To become India's most trusted property marketplace, revolutionizing how people buy and sell real estate with technology and trust.
                </p>
              </div>
            </div>
          </div>

          {/* Why Choose Us */}
          <div className="bg-white rounded-2xl shadow-xl p-12">
            <h2 className="text-4xl font-bold text-gray-800 mb-8">
              Why Should You Choose Us?
            </h2>

            <div className="space-y-6">
              <div className="flex items-start">
                <div className="flex-shrink-0 w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold text-xl mr-4">
                  1
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-2">Exclusive Selection</h3>
                  <p className="text-gray-700 leading-relaxed">
                    We offer a carefully curated selection of premium properties, ranging from luxury apartments to beautiful villas. 
                    Whatever your needs, we've got you covered!
                  </p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="flex-shrink-0 w-12 h-12 bg-green-600 text-white rounded-full flex items-center justify-center font-bold text-xl mr-4">
                  2
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-2">Seamless Experience</h3>
                  <p className="text-gray-700 leading-relaxed">
                    Our platform is designed to be as user-friendly as possible, offering a seamless experience from start to finish. 
                    From browsing properties to easy checkout, working with us is effortless!
                  </p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="flex-shrink-0 w-12 h-12 bg-purple-600 text-white rounded-full flex items-center justify-center font-bold text-xl mr-4">
                  3
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-2">Trusted & Verified</h3>
                  <p className="text-gray-700 leading-relaxed">
                    Every property on our platform goes through rigorous verification. We ensure complete transparency and legal compliance 
                    so you can invest with confidence.
                  </p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="flex-shrink-0 w-12 h-12 bg-orange-600 text-white rounded-full flex items-center justify-center font-bold text-xl mr-4">
                  4
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-2">Expert Support</h3>
                  <p className="text-gray-700 leading-relaxed">
                    Our dedicated team of property experts is available 24/7 to guide you through every step. 
                    Get personalized assistance whenever you need it!
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-4">Ready to Find Your Dream Property?</h2>
          <p className="text-xl mb-8">Join thousands of satisfied property owners today!</p>
          <a
            href="/listings"
            className="inline-block bg-white text-blue-600 px-10 py-4 rounded-full text-lg font-bold hover:bg-gray-100 transition shadow-xl"
          >
            Explore Properties Now
          </a>
        </div>
      </div>
    </div>
  );
};

export default About;