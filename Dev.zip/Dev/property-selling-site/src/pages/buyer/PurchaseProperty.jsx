import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { FaUniversity, FaUser, FaHome, FaArrowLeft, FaCheckCircle } from 'react-icons/fa';
import api from '../../services/api';
import { toast } from 'react-toastify';

const PurchaseProperty = () => {
  // Extract id from URL
  const { id } = useParams();
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [txnId, setTxnId] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchInfo = async () => {
      try {
        setLoading(true);
        // FIX: Added logging to debug the exact response from Rohit Sharma's property
        console.log("Fetching for ID:", id);
        
        const res = await api.get(`/banks/purchase-info/${id}`);
        console.log("API Response:", res.data);

        // Ensure we set data even if some fields are null
        if (res.data) {
          setData(res.data);
        } else {
          toast.error("No data returned from server");
        }
      } catch (err) {
        console.error("Fetch error:", err);
        toast.error(err.response?.data?.message || "Error loading payment information");
      } finally {
        setLoading(false);
      }
    };
    
    // Safety check for ID
    if (id) {
      fetchInfo();
    } else {
      setLoading(false);
      toast.error("Invalid Property ID in URL");
    }
  }, [id]);

  const handlePurchase = async () => {
    if (!txnId.trim()) return toast.error("Transaction ID is required");
    
    try {
      const formData = new FormData();
      formData.append('property_id', id);
      formData.append('transaction_ref', txnId);
      formData.append('payment_mode', 'bank_transfer');

      await api.post('/transactions/', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      }); 
      
      toast.success("Payment proof submitted for approval!");
      navigate('/buyer/transactions');
    } catch (err) {
      console.error("Purchase error:", err);
      toast.error(err.response?.data?.message || "Purchase failed");
    }
  };

  if (loading) return <div className="p-20 text-center text-blue-600 font-semibold italic animate-pulse">Loading Property & Bank Details...</div>;
  
  // NECESSARY CHANGE: Improved condition to prevent the "Not Found" error 
  // while data is transitioning or if only bank is missing
  if (!data || !data.property) return (
    <div className="p-20 text-center">
      <div className="bg-red-50 inline-block p-6 rounded-full mb-4">
        <FaHome className="text-red-400 text-4xl" />
      </div>
      <h2 className="text-xl font-bold text-red-500 mb-2">Property details not found.</h2>
      <p className="text-gray-500 mb-6">We couldn't retrieve the details for Property ID: {id}</p>
      <button onClick={() => navigate(-1)} className="bg-gray-800 text-white px-6 py-2 rounded-lg hover:bg-gray-700 transition flex items-center justify-center gap-2 mx-auto">
        <FaArrowLeft /> Go Back
      </button>
    </div>
  );

  const { property, bank } = data;

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-4xl mx-auto bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
        
        {/* Header */}
        <div className="bg-[#2563EB] p-8 text-white flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold">Finalize Purchase</h1>
            <p className="text-blue-100 text-sm">Please transfer the amount to the seller's bank below</p>
          </div>
          <button onClick={() => navigate(-1)} className="p-2 bg-white/20 rounded-full hover:bg-white/30 transition">
            <FaArrowLeft />
          </button>
        </div>

        <div className="p-8 grid md:grid-cols-2 gap-8">
          {/* Left Side: Property & Seller Info */}
          <div className="space-y-6">
            <div className="flex gap-4">
              <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl h-fit"><FaHome size={24}/></div>
              <div>
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest">Property</h4>
                <p className="text-xl font-bold text-gray-800">{property.title}</p>
                <p className="text-blue-600 font-medium">{property.property_type}</p>
                <p className="text-2xl font-black mt-2">₹{Number(property.price).toLocaleString()}</p>
              </div>
            </div>

            <div className="flex gap-4 pt-6 border-t border-gray-100">
              <div className="p-3 bg-green-50 text-green-600 rounded-2xl h-fit"><FaUser size={24}/></div>
              <div>
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest">Seller</h4>
                <p className="text-lg font-bold text-gray-800">{property.seller_name}</p>
                <p className="text-sm text-gray-500">{property.seller_email}</p>
              </div>
            </div>
          </div>

          {/* Right Side: Bank Details */}
          <div className="bg-gray-50 p-6 rounded-3xl border-2 border-dashed border-gray-200">
            <div className="flex items-center gap-2 mb-4 text-gray-700">
              <FaUniversity className="text-blue-600" />
              <h3 className="font-bold">Seller Bank Account</h3>
            </div>
            
            {bank ? (
              <div className="space-y-4">
                <div>
                  <p className="text-[10px] text-gray-400 font-bold uppercase">Bank Name</p>
                  <p className="font-bold text-gray-800">{bank.bank_name}</p>
                </div>
                <div>
                  <p className="text-[10px] text-gray-400 font-bold uppercase">Account Holder</p>
                  <p className="font-bold text-gray-800">{bank.account_holder_name}</p>
                </div>
                <div>
                  <p className="text-[10px] text-gray-400 font-bold uppercase">Account Number</p>
                  <p className="font-mono text-lg font-bold text-blue-700 bg-white p-2 rounded-lg border border-gray-200">{bank.account_number}</p>
                </div>
                <div>
                  <p className="text-[10px] text-gray-400 font-bold uppercase">IFSC Code</p>
                  <p className="font-mono font-bold">{bank.ifsc_code}</p>
                </div>
              </div>
            ) : (
              <div className="bg-red-50 p-4 rounded-xl border border-red-100">
                <p className="text-red-500 text-sm font-bold">No primary bank details found for this seller. Please contact the seller to proceed.</p>
              </div>
            )}
          </div>
        </div>

        {/* Transaction Input */}
        <div className="p-8 bg-blue-50/50 border-t border-gray-100">
          <div className="max-w-md mx-auto space-y-4">
            <label className="block text-center font-bold text-gray-700">Enter Transaction ID / UTR Number</label>
            <input 
              type="text"
              value={txnId}
              onChange={(e) => setTxnId(e.target.value)}
              className="w-full p-4 rounded-xl border-2 border-gray-200 focus:border-blue-500 outline-none text-center text-lg font-mono"
              placeholder="e.g. 123456789012"
              required
            />
            <button 
              onClick={handlePurchase}
              disabled={!bank}
              className={`w-full py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-2 transition-all ${
                !bank ? 'bg-gray-300 cursor-not-allowed' : 'bg-[#10B981] text-white hover:bg-green-600 shadow-lg'
              }`}
            >
              <FaCheckCircle /> Make Purchase
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PurchaseProperty;