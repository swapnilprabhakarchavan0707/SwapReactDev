import React, { useState, useEffect } from 'react';
import { FaHistory, FaFileInvoiceDollar, FaDownload, FaCopy, FaFilePdf } from 'react-icons/fa';
import api from '../../services/api';
import { toast } from 'react-toastify';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

const TransactionHistory = () => {
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchHistory = async () => {
      try {
        const res = await api.get('/transactions/buyer');
        const completedRecords = (res.data.transactions || []).filter(
          (item) => item.admin_approval?.toLowerCase() !== 'pending'
        );
        setRecords(completedRecords);
      } catch (err) {
        toast.error("Could not load transaction history");
      } finally {
        setLoading(false);
      }
    };
    fetchHistory();
  }, []);

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast.info("Reference ID copied!");
  };

  const downloadPDF = (item) => {
    const doc = new jsPDF();
    doc.setFontSize(18);
    doc.text("Transaction Receipt", 14, 22);
    doc.setFontSize(11);
    doc.setTextColor(100);
    
    const tableData = [
      ["Property", item.title],
      ["Address", item.address || "N/A"],
      ["Reference No", item.transaction_ref],
      ["Payment Mode", item.payment_mode],
      ["Amount", `Rs. ${Number(item.price).toLocaleString()}`],
      ["Status", item.admin_approval.toUpperCase()],
      ["Date", new Date(item.created_at).toLocaleDateString()]
    ];

    // Changed: Call autoTable directly passing 'doc'
    autoTable(doc, {
      startY: 30,
      body: tableData,
      theme: 'striped',
    });

    doc.save(`Receipt_${item.transaction_ref}.pdf`);
  };

  const getStatusBadge = (status) => {
    const s = status?.toLowerCase();
    if (s === 'approved' || s === 'completed') {
      return <span className="ml-2 px-2 py-0.5 text-[10px] bg-green-100 text-green-700 rounded-full border border-green-200">SUCCESSFUL</span>;
    }
    if (s === 'rejected' || s === 'failed') {
      return <span className="ml-2 px-2 py-0.5 text-[10px] bg-red-100 text-red-700 rounded-full border border-red-200">REJECTED</span>;
    }
    return null;
  };

  if (loading) return <div className="p-20 text-center text-gray-500 font-medium">Loading history...</div>;

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <div className="bg-blue-600 p-3 rounded-2xl shadow-lg">
            <FaHistory className="text-white text-2xl" />
          </div>
          <h1 className="text-3xl font-bold text-gray-800">Transaction History</h1>
        </div>

        <div className="space-y-4">
          {records.map((item) => (
            <div key={item.transaction_id} className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 flex flex-col md:flex-row justify-between items-center hover:border-blue-300 transition-colors">
              <div className="flex items-center gap-6">
                <div className="hidden sm:block text-4xl">📄</div>
                <div>
                  <div className="flex items-center">
                    <h3 className="font-bold text-gray-800 text-lg">{item.title}</h3>
                    {getStatusBadge(item.admin_approval)}
                  </div>
                  <div className="flex items-center gap-2 group">
                    <p className="text-sm text-gray-500 font-mono">{item.transaction_ref}</p>
                    <button onClick={() => copyToClipboard(item.transaction_ref)} className="text-gray-400 hover:text-blue-600 transition" title="Copy Reference">
                      <FaCopy size={12} />
                    </button>
                  </div>
                  <p className="text-xs text-blue-600 font-semibold mt-1 uppercase">{item.payment_mode}</p>
                </div>
              </div>

              <div className="mt-4 md:mt-0 flex flex-col items-end">
                <p className="text-2xl font-black text-gray-900">₹{Number(item.price).toLocaleString()}</p>
                <p className="text-xs text-gray-400 mb-3">{new Date(item.created_at).toLocaleDateString('en-IN')}</p>
                
                <div className="flex gap-3">
                    <button onClick={() => downloadPDF(item)} className="inline-flex items-center gap-2 text-xs font-bold text-red-600 hover:text-red-800">
                      <FaFilePdf /> PDF
                    </button>
                    {item.payment_proof && (
                    <a href={`http://localhost:5000/${item.payment_proof}`} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 text-xs font-bold text-blue-600 hover:text-blue-800">
                        <FaDownload /> RECEIPT
                    </a>
                    )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {records.length === 0 && (
          <div className="text-center py-20 bg-white rounded-3xl border-2 border-dashed border-gray-200">
            <FaFileInvoiceDollar className="mx-auto text-5xl text-gray-200 mb-4" />
            <p className="text-gray-400">Your transaction history is currently empty.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default TransactionHistory;