import React, { useState, useEffect } from 'react';
import { FaUserTie, FaEnvelope, FaPhoneAlt, FaSearch, FaHistory } from 'react-icons/fa';
import api from '../../services/api';
import { toast } from 'react-toastify';

const SellerDetails = () => {
  const [sellers, setSellers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const fetchSellers = async () => {
      try {
        setLoading(true);
        const res = await api.get('/transactions/buyer');
        
        // Filter unique sellers from the transaction list
        const uniqueSellersMap = new Map();
        
        res.data.transactions.forEach(item => {
          if (!uniqueSellersMap.has(item.seller_id)) {
            uniqueSellersMap.set(item.seller_id, {
              id: item.seller_id,
              name: item.seller_name,
              email: item.seller_email,
              phone: item.seller_phone
            });
          }
        });

        setSellers(Array.from(uniqueSellersMap.values()));
      } catch (err) {
        toast.error("Failed to load seller contact information");
      } finally {
        setLoading(false);
      }
    };
    fetchSellers();
  }, []);

  const filteredSellers = sellers.filter(seller =>
    seller.name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) return <div className="p-20 text-center animate-pulse">Loading Seller Directory...</div>;

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-4xl font-extrabold text-gray-900">Seller Details</h1>
            <p className="text-gray-500 mt-2">Verified contact information of property owners</p>
          </div>

          <div className="relative">
            <FaSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input 
              type="text"
              placeholder="Search seller by name..."
              className="pl-10 pr-4 py-3 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none w-full md:w-80 shadow-sm"
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        <div className="bg-white rounded-[2rem] shadow-xl border border-gray-100 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-gray-900 text-white">
                  <th className="px-8 py-5 text-sm font-semibold uppercase tracking-wider">Sr. No</th>
                  <th className="px-8 py-5 text-sm font-semibold uppercase tracking-wider">Seller Name</th>
                  <th className="px-8 py-5 text-sm font-semibold uppercase tracking-wider">Email Address</th>
                  <th className="px-8 py-5 text-sm font-semibold uppercase tracking-wider">Phone Number</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filteredSellers.map((seller, index) => (
                  <tr key={seller.id} className="hover:bg-blue-50/50 transition-colors group">
                    <td className="px-8 py-5 text-gray-400 font-mono">
                      {String(index + 1).padStart(2, '0')}
                    </td>
                    <td className="px-8 py-5">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-md group-hover:scale-110 transition-transform">
                          <FaUserTie />
                        </div>
                        <span className="font-bold text-gray-800 text-lg">{seller.name}</span>
                      </div>
                    </td>
                    <td className="px-8 py-5 text-gray-600">
                      <div className="flex items-center gap-2 hover:text-blue-600 cursor-pointer">
                        <FaEnvelope className="text-blue-400" /> {seller.email}
                      </div>
                    </td>
                    <td className="px-8 py-5 text-gray-600">
                      <div className="flex items-center gap-2 hover:text-green-600 cursor-pointer">
                        <FaPhoneAlt className="text-green-400" /> {seller.phone}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filteredSellers.length === 0 && (
            <div className="py-20 text-center">
              <FaHistory className="mx-auto text-5xl text-gray-200 mb-4" />
              <p className="text-gray-400 text-xl font-medium">No sellers found in your records.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SellerDetails;