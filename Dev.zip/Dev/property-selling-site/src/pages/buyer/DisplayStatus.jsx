import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FaClock, FaCheckCircle, FaTimesCircle, FaReceipt, FaHome } from 'react-icons/fa';
import api from '../../services/api';
import { toast } from 'react-toastify';

const DisplayStatus = () => {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        setLoading(true);
        const res = await api.get('/transactions/buyer');
        
        // CHANGE: Filter to only show transactions where status is 'pending'
        // This ensures completed/rejected records move to the Transaction History page
        const activeRequests = (res.data.transactions || []).filter(
          (txn) => txn.admin_approval?.toLowerCase() === 'pending'
        );
        
        setTransactions(activeRequests);
      } catch (err) {
        console.error("Fetch error:", err);
        toast.error("Failed to load purchase status");
      } finally {
        setLoading(false);
      }
    };
    fetchStatus();
  }, []);

  const getStatusStyle = (status) => {
    switch (status?.toLowerCase()) {
      case 'approved':
      case 'completed':
        return 'bg-green-100 text-green-700 border-green-200';
      case 'rejected':
      case 'failed':
        return 'bg-red-100 text-red-700 border-red-200';
      default:
        return 'bg-yellow-100 text-yellow-700 border-yellow-200';
    }
  };

  const getStatusIcon = (status) => {
    switch (status?.toLowerCase()) {
      case 'approved':
      case 'completed':
        return <FaCheckCircle />;
      case 'rejected':
      case 'failed':
        return <FaTimesCircle />;
      default:
        return <FaClock className="animate-pulse" />;
    }
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-blue-600 font-semibold animate-pulse text-xl">
        Fetching live status...
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Live Application Status</h1>
            <p className="text-gray-500 mt-1">Tracking your active property purchase requests</p>
          </div>
          <Link to="/listings" className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition flex items-center gap-2">
            <FaHome /> Browse Properties
          </Link>
        </div>

        {transactions.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center shadow-sm border border-gray-100">
            <div className="bg-gray-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
              <FaReceipt className="text-gray-300 text-3xl" />
            </div>
            <h3 className="text-xl font-bold text-gray-700">No pending applications</h3>
            <p className="text-gray-500 mt-2">Check "Transaction History" for your completed or rejected purchases.</p>
          </div>
        ) : (
          <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-100">
                    <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-widest">Property</th>
                    <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-widest">UTR / Ref No.</th>
                    <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-widest">Price</th>
                    <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-widest">Applied On</th>
                    <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-widest text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {transactions.map((txn) => (
                    <tr key={txn.transaction_id} className="hover:bg-gray-50/50 transition">
                      <td className="px-6 py-4">
                        <p className="font-bold text-gray-800">{txn.title}</p>
                        <p className="text-xs text-gray-500">{txn.address}</p>
                      </td>
                      <td className="px-6 py-4">
                        <span className="font-mono text-sm bg-gray-100 px-2 py-1 rounded">
                          {txn.transaction_ref}
                        </span>
                      </td>
                      <td className="px-6 py-4 font-bold text-gray-800">
                        ₹{Number(txn.price).toLocaleString()}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600">
                        {new Date(txn.created_at).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 text-center">
                        <span className={`inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-bold border ${getStatusStyle(txn.admin_approval)}`}>
                          {getStatusIcon(txn.admin_approval)}
                          <span className="uppercase">{txn.admin_approval}</span>
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DisplayStatus;