import { Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchProperties } from '../redux/slices/propertySlice';

const propertyImages = [
  'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=900',
  'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=900',
  'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=900',
  'https://images.unsplash.com/photo-1505691938895-1758d7feb511?w=900',
  'https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?w=900',
  'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=900',
];

const Home = () => {
  const dispatch = useDispatch();
  const { properties } = useSelector((state) => state.property);
  const [featuredProperties, setFeaturedProperties] = useState([]);

  useEffect(() => {
    dispatch(fetchProperties());
  }, [dispatch]);

  useEffect(() => {
    setFeaturedProperties(properties.slice(0, 6));
  }, [properties]);

  return (
    <div>
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-5xl font-bold mb-6">Find Your Dream Property</h1>
          <p className="text-xl mb-8">Browse thousands of properties and find the perfect home</p>
          <Link to="/listings" className="bg-white text-blue-600 px-8 py-3 rounded-lg text-lg font-semibold hover:bg-blue-50 inline-block" >
            Browse Properties
          </Link>
        </div>
      </div>

      {/* Featured Properties */}
      <div className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold mb-8 text-center">Featured Properties</h2>
        {featuredProperties.length === 0 ? (
          <div className="text-center text-gray-600">
            <p>No properties available at the moment.</p>
            <p className="mt-2">Check back later for new listings!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredProperties.map((property) => {
              // UPDATED IMAGE LOGIC: Check for DB image first
              const displayImage = property.image 
                ? `http://localhost:5000${property.image}` 
                : propertyImages[property.property_id % propertyImages.length];

              return (
                <Link 
                  key={property.property_id} 
                  to={`/property/${property.property_id}`} 
                  className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition group" 
                >
                  <div className="overflow-hidden h-48">
                    <img 
                      src={displayImage}
                      alt={property.title} 
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" 
                      onError={(e) => { e.target.src = propertyImages[0]; }}
                    />
                  </div>
                  <div className="p-4">
                    <h3 className="text-xl font-bold mb-2">{property.title}</h3>
                    <p className="text-gray-600 mb-2">{property.city}</p>
                    <p className="text-blue-600 text-xl font-bold">₹{Number(property.price).toLocaleString()}</p>
                    <span className="inline-block bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm mt-2">
                      {property.property_type}
                    </span>
                  </div>
                </Link>
              );
            })}
          </div>
        )}
      </div>

      {/* Features Section */}
      <div className="bg-gray-100 py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-center">Why Choose Us</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-blue-600 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl"> 🏠 </div>
              <h3 className="text-xl font-bold mb-2">Wide Selection</h3>
              <p className="text-gray-600">Browse thousands of verified properties</p>
            </div>
            <div className="text-center">
              <div className="bg-blue-600 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl"> ✓ </div>
              <h3 className="text-xl font-bold mb-2">Trusted Platform</h3>
              <p className="text-gray-600">Secure and reliable transactions</p>
            </div>
            <div className="text-center">
              <div className="bg-blue-600 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl"> 💬 </div>
              <h3 className="text-xl font-bold mb-2">24/7 Support</h3>
              <p className="text-gray-600">We're here to help anytime</p>
            </div>
          </div>
        </div>
      </div>

      {/* Call to Action */}
      <div className="bg-blue-600 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Find Your Dream Property?</h2>
          <p className="text-xl mb-8">Join thousands of satisfied customers today</p>
          <Link to="/register" className="bg-white text-blue-600 px-8 py-3 rounded-lg text-lg font-semibold hover:bg-blue-50 inline-block" >
            Get Started
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Home;