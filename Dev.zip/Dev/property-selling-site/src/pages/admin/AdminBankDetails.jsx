import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import { toast } from 'react-toastify';
import { FaPlus, FaUniversity, FaTimes, FaEdit, FaCheckCircle } from 'react-icons/fa';

const AdminBankDetails = () => {
  const [banks, setBanks] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [editId, setEditId] = useState(null); 

  const [formData, setFormData] = useState({
    bank_name: '',
    account_number: '',
    ifsc_code: '',
    account_holder_name: '',
    upi_id: '',
    is_primary: 0
  });

  const fetchBanks = async () => {
    try {
      const res = await api.get('/transactions/admin/bank');
      setBanks(res.data.bankDetails || []);
    } catch (err) {
      toast.error("Could not load bank accounts");
    }
  };

  useEffect(() => { fetchBanks(); }, []);

  const handleEditClick = (bank) => {
    setEditId(bank.bank_id);
    setFormData({
      bank_name: bank.bank_name,
      account_number: bank.account_number,
      ifsc_code: bank.ifsc_code,
      account_holder_name: bank.account_holder_name,
      upi_id: bank.upi_id || '',
      is_primary: bank.is_primary
    });
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCancel = () => {
    setShowForm(false);
    setEditId(null);
    setFormData({ bank_name: '', account_number: '', ifsc_code: '', account_holder_name: '', upi_id: '', is_primary: 0 });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (editId) {
        await api.put(`/transactions/admin/bank/${editId}`, formData);
        toast.success("Bank details updated!");
      } else {
        await api.post('/transactions/admin/bank', formData);
        toast.success("Bank account added!");
      }
      handleCancel();
      fetchBanks();
    } catch (err) {
      toast.error("Operation failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Bank Accounts</h2>
          <p className="text-sm text-gray-500">Manage your payout destinations</p>
        </div>
        {!showForm && (
          <button onClick={() => setShowForm(true)} className="bg-[#365DEB] text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700 transition-colors">
            <FaPlus /> Add New
          </button>
        )}
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="mb-8 p-6 bg-gray-50 rounded-xl grid grid-cols-1 md:grid-cols-2 gap-4 border border-gray-200">
          <div className="md:col-span-2 flex justify-between items-center">
            <h3 className="font-bold text-[#365DEB] uppercase tracking-wider">{editId ? 'Edit Account' : 'Add New Account'}</h3>
            <button type="button" onClick={handleCancel} className="text-gray-400 hover:text-red-500"><FaTimes /></button>
          </div>
          <input placeholder="Bank Name" className="p-3 rounded-lg border focus:ring-2 focus:ring-blue-400 outline-none" value={formData.bank_name} onChange={e => setFormData({...formData, bank_name: e.target.value})} required />
          <input placeholder="Account Number" className="p-3 rounded-lg border focus:ring-2 focus:ring-blue-400 outline-none" value={formData.account_number} onChange={e => setFormData({...formData, account_number: e.target.value})} required />
          <input placeholder="IFSC Code" className="p-3 rounded-lg border focus:ring-2 focus:ring-blue-400 outline-none" value={formData.ifsc_code} onChange={e => setFormData({...formData, ifsc_code: e.target.value})} required />
          <input placeholder="Holder Name" className="p-3 rounded-lg border focus:ring-2 focus:ring-blue-400 outline-none" value={formData.account_holder_name} onChange={e => setFormData({...formData, account_holder_name: e.target.value})} required />
          <input placeholder="UPI ID (Optional)" className="p-3 rounded-lg border focus:ring-2 focus:ring-blue-400 outline-none" value={formData.upi_id} onChange={e => setFormData({...formData, upi_id: e.target.value})} />
          
          <div className="flex items-center gap-2">
            <input type="checkbox" id="primary-check" className="w-4 h-4 accent-blue-600" checked={formData.is_primary === 1} onChange={e => setFormData({...formData, is_primary: e.target.checked ? 1 : 0})} />
            <label htmlFor="primary-check" className="text-sm font-medium text-gray-700">Set as Primary Account</label>
          </div>
          
          <div className="md:col-span-2 flex gap-3 mt-2">
            <button type="submit" disabled={loading} className="bg-[#365DEB] text-white px-8 py-3 rounded-lg font-bold hover:shadow-lg transition-all flex-1">
              {loading ? 'Processing...' : editId ? 'Update Details' : 'Save Details'}
            </button>
          </div>
        </form>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {banks.map((bank) => (
          <div key={bank.bank_id} className={`p-6 rounded-2xl border-2 transition-all ${bank.is_primary ? 'border-[#365DEB] bg-blue-50/30' : 'border-gray-100 bg-white'}`}>
            <div className="flex justify-between items-start mb-4">
              <div className="bg-white p-3 rounded-xl shadow-sm border border-gray-100">
                <FaUniversity className="text-2xl text-[#365DEB]" />
              </div>
              {/* Only Edit button remains here */}
              <button 
                onClick={() => handleEditClick(bank)} 
                className="text-gray-400 hover:text-[#365DEB] p-2 hover:bg-white rounded-xl transition-all shadow-sm border border-transparent hover:border-gray-200"
                title="Edit Account"
              >
                <FaEdit size={18} />
              </button>
            </div>
            
            <div className="space-y-1">
              <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">{bank.bank_name}</p>
              <h3 className="text-xl font-bold text-gray-800">{bank.account_number}</h3>
            </div>

            <div className="mt-4 pt-4 border-t border-gray-100 flex justify-between items-center">
               <span className="text-sm text-gray-500 font-medium">IFSC: {bank.ifsc_code}</span>
               {bank.is_primary === 1 && (
                <span className="flex items-center gap-1 text-[#365DEB] text-xs font-bold uppercase tracking-tighter bg-white px-2 py-1 rounded-md border border-blue-100">
                  <FaCheckCircle /> Primary
                </span>
               )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminBankDetails;