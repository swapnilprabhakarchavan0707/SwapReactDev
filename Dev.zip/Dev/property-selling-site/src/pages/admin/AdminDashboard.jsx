import { Link } from 'react-router-dom';

const AdminDashboard = () => {
  const adminActions = [
    { title: 'Manage Admin', path: '/admin/manage', icon: '🛡️' },
    { title: 'Manage Seller', path: '/admin/sellers', icon: '🏬' },
    { title: 'Manage Buyer', path: '/admin/buyers', icon: '👥' },
    { title: 'Manage Properties', path: '/admin/properties', icon: '🏠' },
    { title: 'Generate Bill', path: '/admin/transactions', icon: '📝' }, 
    { title: 'Reviews', path: '/admin/reviews', icon: '⭐' },
  ];

  return (
    <div className="container mx-auto px-4 py-12 min-h-[60vh]">
      <div className="bg-white rounded-3xl shadow-xl p-10 md:p-16 border border-gray-100 relative overflow-hidden">
        {/* Decorative Background Element */}
        <div className="absolute top-[-10%] right-[-10%] w-64 h-64 bg-[#365DEB]/5 rounded-full blur-3xl"></div>
        
        <h1 className="text-5xl md:text-6xl font-bold mb-6 text-[#365DEB]">Admin Dashboard</h1>
        
        <div className="flex items-center space-x-4 mb-12">
          <div className="h-1.5 w-16 bg-[#365DEB] rounded-full"></div>
          <p className="text-xl text-gray-600">
            Welcome to the <span className="font-semibold text-[#365DEB]">Admin Panel!</span>
          </p>
        </div>

        {/* Glassmorphism Box */}
        <div className="bg-white/40 backdrop-blur-md border border-white/60 rounded-3xl p-8 shadow-inner relative z-10">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {adminActions.map((action, index) => (
              <Link
                key={index}
                to={action.path}
                className="group flex flex-col items-center justify-center p-8 bg-white border border-gray-100 rounded-2xl transition-all duration-300 hover:bg-[#365DEB] hover:shadow-lg hover:-translate-y-1"
              >
                <span className="text-4xl mb-3 group-hover:scale-110 transition-transform">
                  {action.icon}
                </span>
                <span className="font-bold text-gray-800 group-hover:text-white transition-colors">
                  {action.title}
                </span>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;