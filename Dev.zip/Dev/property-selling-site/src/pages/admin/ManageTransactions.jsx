import React, { useState, useEffect } from 'react';
import { FaUniversity, FaHistory, FaUsers, FaCheck, FaTimes, FaCopy, FaFilePdf, FaSearch, FaClock } from 'react-icons/fa';
import api from '../../services/api';
import { toast } from 'react-toastify';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import AdminBankDetails from './AdminBankDetails';

const ManageTransactions = () => {
  const [view, setView] = useState('pending'); // pending, bank, admin_history, seller_history
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const fetchData = async () => {
    setLoading(true);
    try {
      let endpoint = '';
      
      // Route Mapping based on your transactionRoutes.js
      if (view === 'pending' || view === 'admin_history') {
        endpoint = '/transactions/seller'; // Admin acting as a seller
      } else if (view === 'seller_history') {
        endpoint = '/transactions/all'; // Master Admin view of all transactions
      }

      if (endpoint) {
        const res = await api.get(endpoint);
        let data = res.data.transactions || [];

        // Filter logic for Admin's own sales
        if (view === 'pending') {
          data = data.filter(t => t.admin_approval?.toLowerCase() === 'pending');
        } else if (view === 'admin_history') {
          data = data.filter(t => t.admin_approval?.toLowerCase() !== 'pending');
        }

        setTransactions(data);
      }
    } catch (err) {
      toast.error("Error fetching transactions");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (view !== 'bank') fetchData();
  }, [view]);

  const handleStatusUpdate = async (id, status) => {
    try {
      await api.put('/transactions/update-status', { transaction_id: id, status });
      toast.success(`Transaction ${status} successfully`);
      fetchData();
    } catch (err) {
      toast.error("Failed to update status");
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast.info("Reference ID Copied!");
  };

  const generatePDF = (item) => {
    const doc = new jsPDF();
    doc.setFontSize(18);
    doc.text("Transaction Invoice", 14, 20);
    autoTable(doc, {
      startY: 30,
      head: [['Field', 'Details']],
      body: [
        ['Property Title', item.title],
        ['Transaction Ref', item.transaction_ref],
        ['Buyer Name', item.buyer_name],
        ['Amount', `Rs. ${item.price}`],
        ['Status', item.admin_approval.toUpperCase()],
        ['Date', new Date(item.created_at).toLocaleDateString()]
      ],
    });
    doc.save(`Invoice_${item.transaction_ref}.pdf`);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Top Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
        <h1 className="text-3xl font-bold text-gray-800">Transaction Management</h1>
        <div className="flex bg-gray-100 p-1 rounded-xl shadow-inner">
          <button 
            onClick={() => setView('bank')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${view === 'bank' ? 'bg-white shadow text-blue-600' : 'text-gray-500'}`}
          >
            <FaUniversity /> Account Details
          </button>
          <button 
            onClick={() => setView('admin_history')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${view === 'admin_history' ? 'bg-white shadow text-indigo-600' : 'text-gray-500'}`}
          >
            <FaHistory /> Admin Transaction
          </button>
          <button 
            onClick={() => setView('seller_history')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${view === 'seller_history' ? 'bg-white shadow text-emerald-600' : 'text-gray-500'}`}
          >
            <FaUsers /> Seller Transaction
          </button>
        </div>
      </div>

      {/* Main View Logic */}
      {view === 'bank' ? (
        <AdminBankDetails />
      ) : (
        <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden">
          <div className="p-6 border-b flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-2">
              <button 
                onClick={() => setView('pending')}
                className={`px-4 py-2 rounded-full text-sm font-bold border ${view === 'pending' ? 'bg-orange-50 border-orange-500 text-orange-600' : 'text-gray-400 border-gray-200'}`}
              >
                <FaClock className="inline mr-1"/> Pending Approvals
              </button>
            </div>
            <div className="relative w-full md:w-64">
              <FaSearch className="absolute left-3 top-3 text-gray-400" />
              <input 
                type="text" 
                placeholder="Search history..." 
                className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 text-gray-500 text-sm uppercase">
                <tr>
                  <th className="px-6 py-4 text-left">Property</th>
                  <th className="px-6 py-4 text-left">Buyer</th>
                  <th className="px-6 py-4 text-left">Reference</th>
                  <th className="px-6 py-4 text-left">Amount</th>
                  <th className="px-6 py-4 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {transactions.filter(t => t.title.toLowerCase().includes(searchTerm.toLowerCase())).map((item) => (
                  <tr key={item.transaction_id} className="hover:bg-gray-50/50">
                    <td className="px-6 py-4 font-semibold">{item.title}</td>
                    <td className="px-6 py-4">{item.buyer_name}</td>
                    <td className="px-6 py-4 font-mono text-sm">{item.transaction_ref}</td>
                    <td className="px-6 py-4 text-blue-600 font-bold">₹{Number(item.price).toLocaleString()}</td>
                    <td className="px-6 py-4">
                      <div className="flex justify-center gap-3">
                        {view === 'pending' ? (
                          <>
                            <button onClick={() => handleStatusUpdate(item.transaction_id, 'approved')} className="text-green-600 p-2 bg-green-50 rounded-lg hover:bg-green-600 hover:text-white"><FaCheck /></button>
                            <button onClick={() => handleStatusUpdate(item.transaction_id, 'rejected')} className="text-red-600 p-2 bg-red-50 rounded-lg hover:bg-red-600 hover:text-white"><FaTimes /></button>
                          </>
                        ) : (
                          <>
                            <button onClick={() => copyToClipboard(item.transaction_ref)} title="Copy ID" className="text-blue-500 hover:bg-blue-50 p-2 rounded-lg"><FaCopy /></button>
                            <button onClick={() => generatePDF(item)} title="Download PDF" className="text-red-500 hover:bg-red-50 p-2 rounded-lg"><FaFilePdf /></button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default ManageTransactions;