import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import { FaEdit, FaTrash, FaArrowLeft, FaPlus } from 'react-icons/fa';
import { fetchAllUsers, updateAdminStatus, deleteAdmin, createAdmin } from '../../redux/slices/authSlice';

const ManageAdmin = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { allUsers, loading } = useSelector((state) => state.auth);

  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [formData, setFormData] = useState({ 
    user_id: '', name: '', email: '', phone: '', password: '', confirmPassword: '', role: 'admin', status: 'inactive' 
  });

  useEffect(() => {
    dispatch(fetchAllUsers());
  }, [dispatch]);

  const handleOpenCreateForm = () => {
    setFormData({ user_id: '', name: '', email: '', phone: '', password: '', confirmPassword: '', role: 'admin', status: 'inactive' });
    setEditMode(false);
    setIsFormOpen(true);
  };

  const handleEdit = (admin) => {
    setFormData({ ...admin, password: '', confirmPassword: '' });
    setEditMode(true);
    setIsFormOpen(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();

    // Check if passwords match
    if (formData.password !== formData.confirmPassword) {
      return toast.error("Passwords do not match!");
    }

    const confirmMsg = editMode ? "Update this admin's details?" : "Register this new admin?";
    
    if (window.confirm(confirmMsg)) {
      if (editMode) {
        // CALL UPDATE ROUTE (PUT)
        dispatch(updateAdminStatus({ id: formData.user_id, userData: formData }));
      } else {
        // CALL CREATE ROUTE (POST)
        dispatch(createAdmin(formData));
      }
      setIsFormOpen(false);
    }
  };

  const togglePermission = (admin) => {
    const newStatus = admin.status === 'blocked' ? 'active' : 'blocked';
    if (window.confirm(`Switch status to ${newStatus.toUpperCase()}?`)) {
      dispatch(updateAdminStatus({ id: admin.user_id, userData: { ...admin, status: newStatus } }));
    }
  };

  if (loading && (!allUsers || allUsers.length === 0)) {
    return <div className="flex justify-center items-center h-screen">Loading Admin Data...</div>;
  }

  const adminsOnly = allUsers ? allUsers.filter(u => u.role === 'admin') : [];

  return (
    <div className="p-8 bg-gray-50 min-h-screen">
      <div className="flex justify-between items-center mb-8">
        <button onClick={() => isFormOpen ? setIsFormOpen(false) : navigate('/admin/dashboard')} className="flex items-center gap-2 text-gray-600 hover:text-[#365DEB] font-bold">
          <FaArrowLeft /> Back
        </button>
        <h2 className="text-3xl font-extrabold text-gray-800">Admin Management</h2>
        {!isFormOpen && (
          <button onClick={handleOpenCreateForm} className="bg-[#365DEB] text-white px-6 py-2 rounded-xl flex items-center gap-2 shadow-md">
            <FaPlus /> New Admin
          </button>
        )}
      </div>

      {isFormOpen ? (
        <div className="bg-white p-8 rounded-3xl shadow-lg max-w-2xl mx-auto border border-gray-100">
          <h2 className="text-2xl font-bold mb-6 text-[#365DEB]">{editMode ? "Edit Admin Account" : "Register New Admin"}</h2>
          
          <form onSubmit={handleSave} className="grid grid-cols-1 gap-4" autoComplete="off">
            <input type="text" style={{display:'none'}} />
            <input type="password" style={{display:'none'}} />

            <input type="text" placeholder="Full Name" className="p-3 border rounded-xl" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} required />
            <input type="email" placeholder="Email Address" className="p-3 border rounded-xl" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} required autoComplete="new-email" />
            <input type="tel" placeholder="Phone Number" className="p-3 border rounded-xl" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} required />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input 
                type="password" 
                placeholder={editMode ? "New Password (Optional)" : "Password"} 
                className="p-3 border rounded-xl" 
                value={formData.password}
                onChange={e => setFormData({...formData, password: e.target.value})} 
                required={!editMode} 
              />
              <input 
                type="password" 
                placeholder="Confirm Password" 
                className="p-3 border rounded-xl" 
                value={formData.confirmPassword}
                onChange={e => setFormData({...formData, confirmPassword: e.target.value})} 
                required={!editMode || formData.password.length > 0} 
              />
            </div>
            
            <div className="flex gap-4 mt-6">
              <button type="submit" className="flex-1 bg-green-600 text-white py-3 rounded-xl font-bold hover:bg-green-700">Confirm Save</button>
              <button type="button" onClick={() => setIsFormOpen(false)} className="flex-1 bg-gray-100 text-gray-600 py-3 rounded-xl font-bold">Cancel</button>
            </div>
          </form>
        </div>
      ) : (
        <div className="bg-white rounded-3xl shadow-xl overflow-hidden border">
           <table className="w-full text-left">
            <thead className="bg-[#365DEB] text-white">
              <tr>
                <th className="p-5">Sr. No</th>
                <th className="p-5">Admin Name</th>
                <th className="p-5">Contact Details</th>
                <th className="p-5 text-center">Current Status</th>
                <th className="p-5 text-center">Permission</th>
                <th className="p-5 text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              {adminsOnly.length > 0 ? (
                adminsOnly.map((admin, index) => (
                  <tr key={admin.user_id} className="border-b hover:bg-gray-50">
                    <td className="p-5">{index + 1}</td>
                    <td className="p-5 font-bold">{admin.name}</td>
                    <td className="p-5 text-sm">{admin.email}<br/>{admin.phone}</td>
                    <td className="p-5 text-center">
                      <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase border ${
                        admin.status === 'blocked' ? 'bg-red-50 text-red-600 border-red-200' : 
                        admin.status === 'active' ? 'bg-green-50 text-green-600 border-green-200' : 
                        'bg-gray-50 text-gray-400 border-gray-200'
                      }`}>
                        {admin.status}
                      </span>
                    </td>
                    <td className="p-5 text-center">
                      <button onClick={() => togglePermission(admin)} className={`w-12 h-6 rounded-full relative transition-all ${admin.status === 'blocked' ? 'bg-red-400' : 'bg-green-500'}`}>
                        <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${admin.status === 'blocked' ? 'left-7' : 'left-1'}`}></div>
                      </button>
                    </td>
                    <td className="p-5 text-center">
                      <div className="flex justify-center gap-4">
                        <FaEdit className="text-blue-500 cursor-pointer" onClick={() => handleEdit(admin)} />
                        <FaTrash className="text-red-400 cursor-pointer" onClick={() => {if(window.confirm("Delete?")) dispatch(deleteAdmin(admin.user_id))}} />
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr><td colSpan="6" className="p-10 text-center text-gray-400">No admin users found.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default ManageAdmin;