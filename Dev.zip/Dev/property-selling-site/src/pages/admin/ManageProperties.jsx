import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchProperties, deleteProperty, updateProperty, addProperty } from '../../redux/slices/propertySlice';
import { FaTrash, FaEye, FaBuilding, FaEdit, FaArrowLeft, FaCloudUploadAlt, FaPlus } from 'react-icons/fa';
import { Link, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';

const ManageProperties = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { properties, loading } = useSelector((state) => state.property);

  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [formData, setFormData] = useState({
    property_id: '', title: '', description: '', price: '', 
    property_type: '1BHK', address: '', city: '', status: 'available', images: []
  });

  useEffect(() => {
    dispatch(fetchProperties({ status: 'all' }));
  }, [dispatch]);

  const handleOpenCreate = () => {
    setFormData({ title: '', description: '', price: '', property_type: '1BHK', address: '', city: '', status: 'available', images: [] });
    setEditMode(false);
    setIsFormOpen(true);
  };

  const handleEditClick = (p) => {
    setFormData({ ...p, images: [] });
    setEditMode(true);
    setIsFormOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const data = new FormData();
    
    // Explicitly append fields matching your database
    data.append('title', formData.title);
    data.append('description', formData.description);
    data.append('price', formData.price);
    data.append('property_type', formData.property_type);
    data.append('address', formData.address);
    data.append('city', formData.city);
    data.append('status', formData.status);

    if (formData.images.length > 0) {
      Array.from(formData.images).forEach(file => data.append('images', file));
    }

    const actionText = editMode ? "Update" : "Add";
    if (window.confirm(`${actionText} this property?`)) {
      const action = editMode 
        ? updateProperty({ id: formData.property_id, formData: data })
        : addProperty(data);

      dispatch(action).then((res) => {
        if (!res.error) {
          toast.success(`Property ${editMode ? 'updated' : 'added'} successfully`);
          setIsFormOpen(false);
          dispatch(fetchProperties({ status: 'all' }));
        } else {
          toast.error("Error adding property. Make sure you are logged in.");
        }
      });
    }
  };

  const handleDelete = (id) => {
    if (window.confirm("Permanently delete this listing?")) {
      dispatch(deleteProperty(id)).then(() => {
        toast.error("Property removed");
        dispatch(fetchProperties({ status: 'all' }));
      });
    }
  };

  if (loading && !isFormOpen) return <div className="p-10 text-center text-blue-600 font-bold">Loading properties...</div>;

  return (
    <div className="p-8 bg-gray-50 min-h-screen">
      <div className="flex justify-between items-center mb-8">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => isFormOpen ? setIsFormOpen(false) : navigate(-1)} 
            className="p-2 bg-white shadow-sm rounded-lg text-gray-600 hover:text-blue-600 border border-gray-200 transition-all"
          >
            <FaArrowLeft size={18} />
          </button>
          <h2 className="text-3xl font-extrabold text-gray-800 flex items-center gap-3">
            <FaBuilding className="text-[#365DEB]" /> 
            {isFormOpen ? (editMode ? "Edit Property" : "Add New Property") : "Property Management"}
          </h2>
        </div>
        {!isFormOpen && (
          <button onClick={handleOpenCreate} className="bg-[#365DEB] text-white px-6 py-2 rounded-xl flex items-center gap-2 shadow-lg hover:bg-blue-700 transition">
            <FaPlus /> New Property
          </button>
        )}
      </div>

      {isFormOpen ? (
        <div className="bg-white rounded-3xl shadow-xl p-8 border border-gray-100 max-w-4xl mx-auto">
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="md:col-span-2">
              <label className="block text-sm font-bold text-gray-700 mb-2">Property Title</label>
              <input type="text" value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} className="w-full p-3 border rounded-xl" placeholder='Enter property title' required />
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">Price (₹)</label>
              <input type="number" value={formData.price} onChange={e => setFormData({...formData, price: e.target.value})} className="w-full p-3 border rounded-xl" placeholder='Enter price' required />
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">Property Type</label>
              <select value={formData.property_type} onChange={e => setFormData({...formData, property_type: e.target.value})} className="w-full p-3 border rounded-xl">
                <option value="1BHK">1BHK</option>
                <option value="2BHK">2BHK</option>
                <option value="3BHK">3BHK</option>
                <option value="Villa">Villa</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">City</label>
              <input type="text" value={formData.city} onChange={e => setFormData({...formData, city: e.target.value})} className="w-full p-3 border rounded-xl" placeholder='Enter city' required />
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">Status</label>
              <select value={formData.status} onChange={e => setFormData({...formData, status: e.target.value})} className="w-full p-3 border rounded-xl">
                <option value="available">Available</option>
                <option value="sold">Sold</option>
              </select>
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-bold text-gray-700 mb-2">Full Address</label>
              <input type="text" value={formData.address} onChange={e => setFormData({...formData, address: e.target.value})} className="w-full p-3 border rounded-xl" placeholder='Enter full address' required />
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-bold text-gray-700 mb-2">Description</label>
              <textarea rows="3" value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} className="w-full p-3 border rounded-xl" placeholder='Enter property description'></textarea>
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-bold text-gray-700 mb-2">Property Images</label>
              <div className="border-2 border-dashed border-gray-200 rounded-xl p-6 text-center hover:border-blue-400 transition">
                <input type="file" multiple onChange={e => setFormData({...formData, images: e.target.files})} className="hidden" id="file-upload" required={!editMode} />
                <label htmlFor="file-upload" className="cursor-pointer flex flex-col items-center gap-2">
                  <FaCloudUploadAlt size={30} className="text-blue-500" />
                  <span className="text-gray-500">{formData.images.length > 0 ? `${formData.images.length} files` : "Upload photos"}</span>
                </label>
              </div>
            </div>

            <div className="md:col-span-2 flex gap-4 mt-4">
              <button type="submit" className="flex-1 bg-green-600 text-white py-3 rounded-xl font-bold shadow hover:bg-green-700 transition">
                {editMode ? "Update Listing" : "Create Listing"}
              </button>
              <button type="button" onClick={() => setIsFormOpen(false)} className="flex-1 bg-gray-100 text-gray-600 py-3 rounded-xl font-bold">Cancel</button>
            </div>
          </form>
        </div>
      ) : (
        <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-gray-100">
          <table className="w-full text-left">
            <thead className="bg-slate-800 text-white text-sm uppercase">
              <tr>
                <th className="p-5">Sr. No</th>
                <th className="p-5">Property Title</th>
                <th className="p-5">City</th>
                <th className="p-5 text-center">Status</th>
                <th className="p-5 text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              {properties.map((p, index) => (
                <tr key={p.property_id} className="border-b hover:bg-blue-50/50 transition">
                  <td className="p-5 text-gray-400 font-medium">{index + 1}</td>
                  <td className="p-5 font-bold text-gray-800">{p.title}</td>
                  <td className="p-5 text-sm text-gray-600">{p.city}</td>
                  <td className="p-5 text-center">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase ${p.status === 'available' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}>
                      {p.status}
                    </span>
                  </td>
                  <td className="p-5 text-center">
                    <div className="flex justify-center gap-3">
                      <Link to={`/property/${p.property_id}`} className="p-2 bg-gray-100 rounded-lg text-gray-600 hover:bg-blue-600 hover:text-white transition"><FaEye size={14}/></Link>
                      <button onClick={() => handleEditClick(p)} className="p-2 bg-blue-50 rounded-lg text-blue-500 hover:bg-blue-600 hover:text-white transition"><FaEdit size={14}/></button>
                      <button onClick={() => handleDelete(p.property_id)} className="p-2 bg-red-50 rounded-lg text-red-500 hover:bg-red-600 hover:text-white transition"><FaTrash size={14}/></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default ManageProperties;