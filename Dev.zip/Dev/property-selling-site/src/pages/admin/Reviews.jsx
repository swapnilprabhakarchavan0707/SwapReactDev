import { useEffect, useState } from 'react';
import { toast } from 'react-toastify';
import { FaTrash, FaCopy, FaEnvelope, FaPhone, FaArrowLeft } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';

const Reviews = () => {
  const [messages, setMessages] = useState([]);
  const navigate = useNavigate();

  const fetchMessages = async () => {
    try {
      const res = await fetch('http://localhost:5000/api/contact/messages');
      if (!res.ok) throw new Error("Server error");
      const data = await res.json();
      setMessages(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Fetch error:", error);
      toast.error("Failed to load reviews.");
    }
  };

  useEffect(() => {
    fetchMessages();
  }, []);

  const handleCopy = (text) => {
    navigator.clipboard.writeText(text);
    toast.info("Copied to clipboard!");
  };

  const handleDelete = async (id) => {
    if (window.confirm("Delete this message permanently?")) {
      try {
        const res = await fetch(`http://localhost:5000/api/contact/${id}`, { 
          method: 'DELETE' 
        });
        if (res.ok) {
          toast.success("Message deleted successfully");
          fetchMessages();
        } else {
          toast.error("Failed to delete from database");
        }
      } catch (error) {
        toast.error("Connection error");
      }
    }
  };

  return (
    <div className="container mx-auto px-4 py-12 min-h-screen bg-gray-50">
      {/* Header with Fixed Back Button Path */}
      <div className="flex items-center gap-4 mb-8">
        <button 
          onClick={() => navigate('/admin/dashboard')} 
          className="p-3 bg-white shadow-sm rounded-xl text-gray-600 hover:text-[#365DEB] border border-gray-200 transition-all hover:shadow-md active:scale-95"
          title="Back to Admin Dashboard"
        >
          <FaArrowLeft size={20} />
        </button>
        <div>
          <h1 className="text-4xl font-extrabold text-gray-800 border-l-8 border-[#365DEB] pl-4">
            Contact Reviews
          </h1>
          <p className="text-gray-500 ml-6 mt-1">Manage messages sent via the contact form</p>
        </div>
      </div>
      
      <div className="grid gap-6">
        {messages.length > 0 ? (
          messages.map((msg) => (
            <div key={msg.id} className="bg-white rounded-2xl shadow-md p-6 border border-gray-100 hover:shadow-lg transition-shadow duration-300">
              <div className="flex flex-col md:flex-row justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h2 className="text-xl font-bold text-[#365DEB]">{msg.name}</h2>
                    <span className="text-xs font-medium text-gray-400 bg-gray-100 px-2 py-1 rounded-md">
                      {msg.created_at ? new Date(msg.created_at).toLocaleDateString() : 'Recent'}
                    </span>
                  </div>
                  
                  <div className="flex flex-wrap gap-4 text-sm text-gray-600 mb-4">
                    <span className="flex items-center gap-2">
                      <FaEnvelope className="text-gray-400"/> 
                      <a href={`mailto:${msg.email}`} className="hover:text-[#365DEB] underline decoration-gray-300">{msg.email}</a>
                    </span>
                    <span className="flex items-center gap-2">
                      <FaPhone className="text-gray-400"/> {msg.phone || 'No Phone Provided'}
                    </span>
                  </div>

                  <div className="bg-slate-50 p-5 rounded-2xl border border-gray-100">
                    <p className="font-bold text-gray-800 mb-2 underline decoration-[#365DEB]/30 underline-offset-4">
                      Subject: {msg.subject}
                    </p>
                    <p className="text-gray-600 whitespace-pre-line leading-relaxed italic">
                      "{msg.message}"
                    </p>
                  </div>
                </div>

                <div className="flex md:flex-col gap-3 justify-end items-center">
                  <button 
                    onClick={() => handleCopy(`Name: ${msg.name}\nEmail: ${msg.email}\nPhone: ${msg.phone}\nSubject: ${msg.subject}\nMessage: ${msg.message}`)}
                    className="p-4 bg-gray-50 text-gray-500 rounded-2xl hover:bg-[#365DEB] hover:text-white transition-all shadow-sm group"
                    title="Copy to Clipboard"
                  >
                    <FaCopy size={20} className="group-hover:scale-110 transition-transform" />
                  </button>
                  <button 
                    onClick={() => handleDelete(msg.id)}
                    className="p-4 bg-red-50 text-red-500 rounded-2xl hover:bg-red-600 hover:text-white transition-all shadow-sm group"
                    title="Delete Message"
                  >
                    <FaTrash size={20} className="group-hover:scale-110 transition-transform" />
                  </button>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-24 bg-white rounded-3xl border-2 border-dashed border-gray-200">
            <div className="text-6xl mb-4">📥</div>
            <p className="text-gray-500 text-xl font-medium">Your inbox is empty.</p>
            <p className="text-gray-400">New messages from the contact form will appear here.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Reviews;