import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import { FaEdit, FaTrash, FaArrowLeft, FaPlus, FaUsers } from 'react-icons/fa';
import { fetchAllUsers, updateAdminStatus, deleteAdmin, createAdmin } from '../../redux/slices/authSlice';

const ManageBuyers = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { allUsers, loading } = useSelector((state) => state.auth);

  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [formData, setFormData] = useState({ 
    user_id: '', name: '', email: '', phone: '', password: '', confirmPassword: '', role: 'buyer', status: 'inactive' 
  });

  useEffect(() => {
    dispatch(fetchAllUsers());
  }, [dispatch]);

  const handleOpenCreateForm = () => {
    setFormData({ user_id: '', name: '', email: '', phone: '', password: '', confirmPassword: '', role: 'buyer', status: 'inactive' });
    setEditMode(false);
    setIsFormOpen(true);
  };

  const handleEdit = (buyer) => {
    setFormData({ ...buyer, password: '', confirmPassword: '' });
    setEditMode(true);
    setIsFormOpen(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    if (formData.password !== formData.confirmPassword) {
      return toast.error("Passwords do not match!");
    }

    if (window.confirm(`Are you sure you want to ${editMode ? 'update' : 'register'} this buyer?`)) {
      if (editMode) {
        dispatch(updateAdminStatus({ id: formData.user_id, userData: formData }));
      } else {
        dispatch(createAdmin(formData));
      }
      setIsFormOpen(false);
      toast.success(editMode ? "Buyer updated" : "Buyer registered");
    }
  };

  const toggleStatus = (buyer) => {
    const newStatus = buyer.status === 'blocked' ? 'active' : 'blocked';
    if (window.confirm(`Switch status to ${newStatus.toUpperCase()}?`)) {
      dispatch(updateAdminStatus({ id: buyer.user_id, userData: { ...buyer, status: newStatus } }));
    }
  };

  if (loading && (!allUsers || allUsers.length === 0)) {
    return <div className="flex justify-center items-center h-screen">Loading Buyers...</div>;
  }

  const buyersOnly = allUsers ? allUsers.filter(u => u.role === 'buyer') : [];

  return (
    <div className="p-8 bg-gray-50 min-h-screen">
      <div className="flex justify-between items-center mb-8">
        <button onClick={() => isFormOpen ? setIsFormOpen(false) : navigate('/admin/dashboard')} className="flex items-center gap-2 text-gray-600 font-bold hover:text-[#365DEB]">
          <FaArrowLeft /> Back
        </button>
        <h2 className="text-3xl font-extrabold text-gray-800 flex items-center gap-3">
          <FaUsers className="text-[#365DEB]" /> Buyer Management
        </h2>
        {!isFormOpen && (
          <button onClick={handleOpenCreateForm} className="bg-[#365DEB] text-white px-6 py-2 rounded-xl flex items-center gap-2 shadow-md">
            <FaPlus /> New Buyer
          </button>
        )}
      </div>

      {isFormOpen ? (
        <div className="bg-white p-8 rounded-3xl shadow-lg max-w-2xl mx-auto border border-gray-100">
          <h2 className="text-2xl font-bold mb-6 text-[#365DEB]">{editMode ? "Edit Buyer Details" : "Register New Buyer"}</h2>
          <form onSubmit={handleSave} className="grid grid-cols-1 gap-4" autoComplete="off">
            {/* Autofill Prevention */}
            <input type="text" style={{display:'none'}} />
            <input type="password" style={{display:'none'}} />

            <input type="text" placeholder="Full Name" className="p-3 border rounded-xl" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} required />
            <input type="email" placeholder="Email Address" className="p-3 border rounded-xl" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} required />
            <input type="tel" placeholder="Phone Number" className="p-3 border rounded-xl" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} required />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input 
                type="password" 
                placeholder={editMode ? "New Password (Optional)" : "Password"} 
                className="p-3 border rounded-xl" 
                value={formData.password}
                onChange={e => setFormData({...formData, password: e.target.value})} 
                required={!editMode} 
              />
              <input 
                type="password" 
                placeholder="Confirm Password" 
                className="p-3 border rounded-xl" 
                value={formData.confirmPassword}
                onChange={e => setFormData({...formData, confirmPassword: e.target.value})} 
                required={!editMode || formData.password.length > 0} 
              />
            </div>
            
            <div className="flex gap-4 mt-6">
              <button type="submit" className="flex-1 bg-green-600 text-white py-3 rounded-xl font-bold">Confirm Save</button>
              <button type="button" onClick={() => setIsFormOpen(false)} className="flex-1 bg-gray-100 text-gray-600 py-3 rounded-xl font-bold">Cancel</button>
            </div>
          </form>
        </div>
      ) : (
        <div className="bg-white rounded-3xl shadow-xl overflow-hidden border">
           <table className="w-full text-left">
            <thead className="bg-[#365DEB] text-white">
              <tr>
                <th className="p-5">Sr. No</th>
                <th className="p-5">Buyer Name</th>
                <th className="p-5">Contact Details</th>
                <th className="p-5 text-center">Current Status</th>
                <th className="p-5 text-center">Account Control</th>
                <th className="p-5 text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              {buyersOnly.length > 0 ? (
                buyersOnly.map((buyer, index) => (
                  <tr key={buyer.user_id} className="border-b hover:bg-gray-50">
                    <td className="p-5 font-medium text-gray-500">{index + 1}</td>
                    <td className="p-5 font-bold text-gray-800">{buyer.name}</td>
                    <td className="p-5 text-sm">
                      <div className="text-gray-700">{buyer.email}</div>
                      <div className="text-gray-500">{buyer.phone}</div>
                    </td>
                    <td className="p-5 text-center">
                      <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase border ${
                        buyer.status === 'blocked' ? 'bg-red-50 text-red-600 border-red-200' : 'bg-green-50 text-green-600 border-green-200'
                      }`}>
                        {buyer.status}
                      </span>
                    </td>
                    <td className="p-5 text-center">
                      <div className="flex justify-center">
                        <button 
                          onClick={() => toggleStatus(buyer)} 
                          className={`w-12 h-6 rounded-full relative transition-all duration-300 ${buyer.status === 'blocked' ? 'bg-gray-300' : 'bg-green-500'}`}
                        >
                          <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all duration-300 ${buyer.status === 'blocked' ? 'left-1' : 'left-7'}`}></div>
                        </button>
                      </div>
                    </td>
                    <td className="p-5 text-center">
                      <div className="flex justify-center gap-4">
                        <FaEdit className="text-blue-500 cursor-pointer hover:scale-125 transition-transform" onClick={() => handleEdit(buyer)} />
                        <FaTrash className="text-red-400 cursor-pointer hover:scale-125 transition-transform" onClick={() => {if(window.confirm("Delete Buyer?")) dispatch(deleteAdmin(buyer.user_id))}} />
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="6" className="p-10 text-center text-gray-400 italic">No buyers registered in the system.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default ManageBuyers;