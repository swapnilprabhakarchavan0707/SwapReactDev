import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FaArrowLeft } from 'react-icons/fa';
import api from '../../services/api';

const AddBankDetail = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    bank_name: '', account_number: '', ifsc_code: '', account_holder_name: '', upi_id: ''
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.post('/banks/add', formData);
      navigate('/seller/bank-details');
    } catch (err) {
      alert("Error adding bank");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
      <form onSubmit={handleSubmit} className="bg-white w-full max-w-2xl p-10 rounded-[40px] shadow-xl border border-gray-100">
        <div className="flex items-center gap-4 mb-8">
          <button type="button" onClick={() => navigate(-1)} className="p-2 bg-gray-50 rounded-full hover:bg-gray-200 transition">
            <FaArrowLeft />
          </button>
          <h1 className="text-2xl font-bold text-gray-800">Add Bank Account</h1>
        </div>

        <div className="space-y-4">
          <div>
            <label className="text-xs font-bold text-gray-500 ml-1">Bank Name</label>
            <input required type="text" placeholder="Enter bank name" className="w-full mt-1 p-3 bg-gray-50 rounded-xl border border-gray-100 focus:outline-blue-400" onChange={e => setFormData({...formData, bank_name: e.target.value})} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold text-gray-500 ml-1">Account Number</label>
              <input required type="text" placeholder="Enter account number" className="w-full mt-1 p-3 bg-gray-50 rounded-xl border border-gray-100 focus:outline-blue-400" onChange={e => setFormData({...formData, account_number: e.target.value})} />
            </div>
            <div>
              <label className="text-xs font-bold text-gray-500 ml-1">IFSC Code</label>
              <input required type="text" placeholder="Enter IFSC code" className="w-full mt-1 p-3 bg-gray-50 rounded-xl border border-gray-100 focus:outline-blue-400" onChange={e => setFormData({...formData, ifsc_code: e.target.value})} />
            </div>
          </div>
          <div>
            <label className="text-xs font-bold text-gray-500 ml-1">Account Holder Name</label>
            <input required type="text" placeholder="Enter holder name" className="w-full mt-1 p-3 bg-gray-50 rounded-xl border border-gray-100 focus:outline-blue-400" onChange={e => setFormData({...formData, account_holder_name: e.target.value})} />
          </div>
          <div>
            <label className="text-xs font-bold text-gray-500 ml-1">UPI ID (Optional)</label>
            <input type="text" placeholder="Enter UPI ID" className="w-full mt-1 p-3 bg-gray-50 rounded-xl border border-gray-100 focus:outline-blue-400" onChange={e => setFormData({...formData, upi_id: e.target.value})} />
          </div>
          
          {/* Action Buttons Row */}
          <div className="flex gap-4 mt-6">
            <button type="submit" className="flex-[2] bg-[#10B981] text-white py-4 rounded-xl font-bold shadow-lg hover:bg-green-600 transition">
              Save Bank Details
            </button>
            <button 
              type="button" 
              onClick={() => navigate('/seller/bank-details')} 
              className="flex-1 bg-gray-100 text-gray-500 py-4 rounded-xl font-bold hover:bg-gray-200 transition"
            >
              Cancel
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default AddBankDetail;