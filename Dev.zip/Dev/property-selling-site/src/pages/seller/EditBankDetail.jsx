import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { FaArrowLeft } from 'react-icons/fa';
import api from '../../services/api';

const EditBankDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    bank_name: '', account_number: '', ifsc_code: '', account_holder_name: '', upi_id: ''
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchBank = async () => {
      try {
        const res = await api.get(`/banks/${id}`);
        if (res.data) {
            setFormData(res.data);
        }
        setLoading(false);
      } catch (err) {
        console.error("Fetch error:", err);
        setLoading(false);
      }
    };
    fetchBank();
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.put(`/banks/update/${id}`, formData);
      navigate('/seller/bank-details');
    } catch (err) {
      alert("Error updating bank details");
    }
  };

  if (loading) return <div className="p-10 text-center text-gray-500">Loading Bank Information...</div>;

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
      <form onSubmit={handleSubmit} className="bg-white w-full max-w-2xl p-10 rounded-[40px] shadow-xl border border-gray-100">
        
        <div className="flex items-center gap-4 mb-8">
          <button 
            type="button" 
            onClick={() => navigate(-1)} 
            className="p-3 bg-gray-100 rounded-full hover:bg-gray-200 transition text-gray-600"
          >
            <FaArrowLeft />
          </button>
          <h1 className="text-2xl font-bold text-gray-800">Edit Bank Account</h1>
        </div>

        <div className="space-y-5">
          <div>
            <label className="text-xs font-bold text-gray-500 uppercase ml-1">Bank Name</label>
            <input 
              required type="text" value={formData.bank_name}
              className="w-full mt-1 p-3 bg-gray-50 rounded-xl border border-gray-100 focus:ring-2 focus:ring-blue-500 outline-none" 
              onChange={e => setFormData({...formData, bank_name: e.target.value})} 
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold text-gray-500 uppercase ml-1">Account Number</label>
              <input 
                required type="text" value={formData.account_number}
                className="w-full mt-1 p-3 bg-gray-50 rounded-xl border border-gray-100" 
                onChange={e => setFormData({...formData, account_number: e.target.value})} 
              />
            </div>
            <div>
              <label className="text-xs font-bold text-gray-500 uppercase ml-1">IFSC Code</label>
              <input 
                required type="text" value={formData.ifsc_code}
                className="w-full mt-1 p-3 bg-gray-50 rounded-xl border border-gray-100" 
                onChange={e => setFormData({...formData, ifsc_code: e.target.value})} 
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-gray-500 uppercase ml-1">Account Holder Name</label>
            <input 
              required type="text" value={formData.account_holder_name}
              className="w-full mt-1 p-3 bg-gray-50 rounded-xl border border-gray-100" 
              onChange={e => setFormData({...formData, account_holder_name: e.target.value})} 
            />
          </div>

          <div>
            <label className="text-xs font-bold text-gray-500 uppercase ml-1">UPI ID (Optional)</label>
            <input 
              type="text" value={formData.upi_id || ''}
              className="w-full mt-1 p-3 bg-gray-50 rounded-xl border border-gray-100" 
              onChange={e => setFormData({...formData, upi_id: e.target.value})} 
            />
          </div>

          <div className="flex gap-4 pt-4">
            <button type="submit" className="flex-1 bg-blue-600 text-white py-4 rounded-xl font-bold shadow-lg hover:bg-blue-700 transition">
              Update Details
            </button>
            <button type="button" onClick={() => navigate('/seller/bank-details')} className="flex-1 bg-gray-100 text-gray-500 py-4 rounded-xl font-bold hover:bg-gray-200 transition">
              Cancel
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default EditBankDetail;