import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import { toast } from 'react-toastify';

const GenerateBill = () => {
  const [pendingTxns, setPendingTxns] = useState([]);

  const fetchPending = async () => {
    const res = await api.get('/transactions/seller');
    // Filter for ONLY pending requests
    setPendingTxns(res.data.transactions.filter(t => t.admin_approval === 'pending'));
  };

  useEffect(() => { fetchPending(); }, []);

  const handleAction = async (id, status) => {
    if (window.confirm(`Are you sure you want to ${status} this transaction?`)) {
      try {
        await api.put('/transactions/update-status', { transaction_id: id, status });
        toast.success(`Transaction ${status}ed`);
        fetchPending(); // Refresh list
      } catch (err) {
        toast.error("Failed to update status");
      }
    }
  };

  return (
    <div className="p-8 bg-white rounded-3xl shadow-sm border border-gray-100">
      <h2 className="text-2xl font-bold mb-6">Transaction Approvals (Pending)</h2>
      <table className="w-full text-left">
        <thead>
          <tr className="bg-gray-50 border-b">
            <th className="p-4">Sr. No</th>
            <th className="p-4">Transaction ID (UTR)</th>
            <th className="p-4">Buyer</th>
            <th className="p-4">Action</th>
          </tr>
        </thead>
        <tbody>
          {pendingTxns.map((txn, index) => (
            <tr key={txn.transaction_id} className="border-b">
              <td className="p-4">{index + 1}</td>
              <td className="p-4 font-mono text-blue-600">{txn.transaction_ref}</td>
              <td className="p-4">{txn.buyer_name}</td>
              <td className="p-4 flex gap-2">
                <button onClick={() => handleAction(txn.transaction_id, 'approved')} className="bg-green-500 text-white px-4 py-1 rounded hover:bg-green-600">Approve</button>
                <button onClick={() => handleAction(txn.transaction_id, 'rejected')} className="bg-red-500 text-white px-4 py-1 rounded hover:bg-red-600">Reject</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default GenerateBill;