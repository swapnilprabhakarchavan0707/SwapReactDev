import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { deleteProperty } from '../../redux/slices/propertySlice';
import api from '../../services/api';
import { FaEdit, FaTrash, FaPlus, FaArrowLeft } from 'react-icons/fa';

const MyProperties = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [myProperties, setMyProperties] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchMyProperties = async () => {
    try {
      setLoading(true);
      const response = await api.get('/properties/seller/my-properties');
      setMyProperties(response.data.properties || []);
      setLoading(false);
    } catch (error) {
      console.error("Failed to fetch properties:", error);
      setLoading(false);
    }
  };

  useEffect(() => { fetchMyProperties(); }, []);

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this property?")) {
      const resultAction = await dispatch(deleteProperty(id));
      if (deleteProperty.fulfilled.match(resultAction)) {
        setMyProperties(myProperties.filter(p => p.property_id !== id));
      }
    }
  };

  if (loading) return <div className="p-10 text-center">Loading...</div>;

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-7xl mx-auto bg-white rounded-[30px] shadow-sm p-8 border border-gray-100">
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-4">
            <button onClick={() => navigate('/seller/dashboard')} className="p-2 bg-gray-100 rounded-full hover:bg-gray-200"><FaArrowLeft /></button>
            <h1 className="text-2xl font-bold text-[#2D3748]">Property Management</h1>
          </div>
          <button onClick={() => navigate('/seller/add-property')} className="bg-[#4C6FFF] text-white px-6 py-2 rounded-xl flex items-center gap-2 font-semibold shadow-lg hover:bg-blue-700 transition">
            <FaPlus /> New Property
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-separate border-spacing-y-4">
            <thead>
              <tr className="bg-[#1A202C] text-white">
                <th className="p-4 rounded-l-xl text-xs uppercase">Sr. No</th>
                <th className="p-4 text-xs uppercase text-left">Property Title</th>
                <th className="p-4 text-xs uppercase text-left">City</th>
                <th className="p-4 text-xs uppercase">Status</th>
                <th className="p-4 rounded-r-xl text-xs uppercase">Actions</th>
              </tr>
            </thead>
            <tbody>
              {myProperties.map((prop, index) => (
                <tr key={prop.property_id} className="bg-white border-b border-gray-100 hover:bg-gray-50 transition">
                  <td className="p-4 text-center text-gray-500">{index + 1}</td>
                  <td className="p-4 font-bold text-gray-800">{prop.title}</td>
                  <td className="p-4 text-gray-600">{prop.city}</td>
                  <td className="p-4 text-center">
                    <span className="px-3 py-1 bg-green-100 text-green-600 rounded-full text-[10px] font-bold uppercase tracking-wider">
                      {prop.status}
                    </span>
                  </td>
                  <td className="p-4">
                    <div className="flex justify-center gap-3">
                      <button onClick={() => navigate(`/seller/edit-property/${prop.property_id}`)} className="p-2 text-blue-400 hover:text-blue-600 bg-blue-50 rounded-lg"><FaEdit /></button>
                      <button onClick={() => handleDelete(prop.property_id)} className="p-2 text-red-400 hover:text-red-600 bg-red-50 rounded-lg"><FaTrash /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default MyProperties;