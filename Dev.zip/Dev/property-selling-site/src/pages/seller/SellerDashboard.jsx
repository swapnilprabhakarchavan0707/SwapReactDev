import React from 'react';
import { Link } from 'react-router-dom';

const SellerDashboard = () => {
  const menuItems = [
    {
      title: 'Manage Properties',
      link: '/seller/properties',
      icon: '🏠', // Replace with your property icon/image
    },
    {
      title: 'Bank Details',
      link: '/seller/bank-details',
      icon: '🏦', // Replace with your bank icon/image
    },
    {
      title: 'Generate Bill',
      link: '/seller/generate-bill',
      icon: '📝', // Replace with your bill/pencil icon/image
    },
    {
      title: 'Transaction History',
      link: '/seller/transactions',
      icon: '📜', // Replace with your history icon/image
    }
  ];

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-6">
      <div className="max-w-6xl w-full bg-white rounded-[40px] shadow-2xl p-12">
        
        {/* Header Section */}
        <div className="mb-12">
          <h1 className="text-5xl font-bold text-blue-600 mb-4">Seller Dashboard</h1>
          <div className="flex items-center gap-4">
            <div className="h-1 w-12 bg-blue-600 rounded-full"></div>
            <p className="text-gray-600 text-lg">
              Welcome to the <span className="text-blue-600 font-semibold">Seller Panel!</span>
            </p>
          </div>
        </div>

        {/* Dashboard Grid Container */}
        <div className="bg-gray-50 rounded-[30px] p-8 border border-gray-100">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {menuItems.map((item, index) => (
              <Link 
                key={index} 
                to={item.link}
                className="bg-white rounded-3xl p-10 flex flex-col items-center justify-center shadow-sm hover:shadow-md transition-shadow border border-gray-50 group"
              >
                <div className="text-5xl mb-4 group-hover:scale-110 transition-transform duration-200">
                  {item.icon}
                </div>
                <span className="text-gray-800 font-bold text-xl text-center">
                  {item.title}
                </span>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SellerDashboard;