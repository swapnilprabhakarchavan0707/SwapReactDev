import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { updateProperty } from '../../redux/slices/propertySlice';
import api from '../../services/api';
import { FaCloudUploadAlt, FaArrowLeft } from 'react-icons/fa'; // Added FaArrowLeft

const EditProperty = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [formData, setFormData] = useState(null);

  useEffect(() => {
    api.get(`/properties/${id}`).then(res => setFormData(res.data.property));
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await dispatch(updateProperty({ id, formData }));
    if (updateProperty.fulfilled.match(res)) navigate('/seller/properties');
  };

  if (!formData) return null;

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
      <form onSubmit={handleSubmit} className="bg-white w-full max-w-4xl p-10 rounded-[40px] shadow-xl border border-gray-100">
        
        {/* Added Back Button and Title */}
        <div className="flex items-center gap-4 mb-8">
          <button 
            type="button"
            onClick={() => navigate(-1)} 
            className="p-3 bg-gray-100 rounded-full hover:bg-gray-200 transition text-gray-600"
          >
            <FaArrowLeft />
          </button>
          <h1 className="text-2xl font-bold text-gray-800">Edit Property</h1>
        </div>

        <div className="mb-6">
          <label className="text-xs font-bold text-gray-500">Property Title</label>
          <input type="text" value={formData.title} className="w-full mt-1 p-3 bg-gray-50 border border-gray-100 rounded-xl font-semibold" onChange={e => setFormData({...formData, title: e.target.value})} />
        </div>

        <div className="grid grid-cols-2 gap-6 mb-6">
          <div>
            <label className="text-xs font-bold text-gray-500">Price (₹)</label>
            <input type="number" value={formData.price} className="w-full mt-1 p-3 bg-gray-50 border border-gray-100 rounded-xl" onChange={e => setFormData({...formData, price: e.target.value})} />
          </div>
          <div>
            <label className="text-xs font-bold text-gray-500">Property Type</label>
            <select value={formData.property_type} className="w-full mt-1 p-3 bg-gray-50 border border-gray-100 rounded-xl" onChange={e => setFormData({...formData, property_type: e.target.value})}>
              <option>1BHK</option><option>2BHK</option><option>3BHK</option><option>House</option>
            </select>
          </div>
          <div>
            <label className="text-xs font-bold text-gray-500">City</label>
            <input type="text" value={formData.city} className="w-full mt-1 p-3 bg-gray-50 border border-gray-100 rounded-xl" onChange={e => setFormData({...formData, city: e.target.value})} />
          </div>
          <div>
            <label className="text-xs font-bold text-gray-500">Status</label>
            <select value={formData.status} className="w-full mt-1 p-3 bg-gray-50 border border-gray-100 rounded-xl" onChange={e => setFormData({...formData, status: e.target.value})}>
              <option>Available</option><option>Sold</option>
            </select>
          </div>
        </div>

        <div className="mb-6">
          <label className="text-xs font-bold text-gray-500">Full Address</label>
          <input type="text" value={formData.address} className="w-full mt-1 p-3 bg-gray-50 border border-gray-100 rounded-xl" onChange={e => setFormData({...formData, address: e.target.value})} />
        </div>

        <div className="mb-6">
          <label className="text-xs font-bold text-gray-500">Description</label>
          <textarea value={formData.description} className="w-full mt-1 p-3 bg-gray-50 border border-gray-100 rounded-xl h-32" onChange={e => setFormData({...formData, description: e.target.value})} />
        </div>

        <div className="mb-8 p-8 border-2 border-dashed border-blue-100 rounded-3xl text-center">
            <FaCloudUploadAlt className="text-blue-400 text-4xl mx-auto mb-2" />
            <p className="text-blue-500 font-bold text-sm">Photos uploaded</p>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <button type="submit" className="bg-[#10B981] text-white py-4 rounded-xl font-bold shadow-lg">Update Details</button>
          <button type="button" onClick={() => navigate('/seller/properties')} className="bg-gray-100 text-gray-500 py-4 rounded-xl font-bold">Cancel</button>
        </div>
      </form>
    </div>
  );
};
export default EditProperty;