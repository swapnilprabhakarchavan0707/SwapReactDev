import React, { useState, useEffect } from 'react';
import { FaHistory, FaCheckCircle, FaTimesCircle, FaUser, FaSearch, FaCopy, FaFilePdf } from 'react-icons/fa';
import api from '../../services/api';
import { toast } from 'react-toastify';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable'; // Changed: Import as a function

const TransactionRecord = () => {
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const fetchHistory = async () => {
      try {
        setLoading(true);
        const res = await api.get('/transactions/seller');
        const historyData = (res.data.transactions || []).filter(
          (item) => item.admin_approval?.toLowerCase() !== 'pending'
        );
        setRecords(historyData);
      } catch (err) {
        toast.error("Failed to load transaction history");
      } finally {
        setLoading(false);
      }
    };
    fetchHistory();
  }, []);

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast.info("Transaction Ref Copied!");
  };

  const downloadPDF = (record) => {
    const doc = new jsPDF();
    doc.text("Sales Record", 14, 15);
    
    // Changed: Call autoTable directly passing 'doc'
    autoTable(doc, {
      startY: 20,
      head: [['Field', 'Details']],
      body: [
        ['Property', record.title],
        ['Buyer Name', record.buyer_name],
        ['UTR Number', record.transaction_ref],
        ['Amount', `Rs. ${Number(record.price).toLocaleString()}`],
        ['Status', record.admin_approval.toUpperCase()],
        ['Date', new Date(record.created_at).toLocaleDateString()],
      ],
    });
    doc.save(`Sale_${record.transaction_ref}.pdf`);
  };

  const filteredRecords = records.filter(record =>
    record.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    record.buyer_name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) return <div className="p-20 text-center text-gray-500 font-medium">Loading history...</div>;

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
          <div className="flex items-center gap-4">
            <div className="bg-gray-800 p-3 rounded-2xl shadow-lg">
              <FaHistory className="text-white text-2xl" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-800">Sales Records</h1>
              <p className="text-gray-500">Archive of finalized sales</p>
            </div>
          </div>

          <div className="relative">
            <FaSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input type="text" placeholder="Search..." className="pl-10 pr-4 py-2 border border-gray-200 rounded-xl outline-none w-full md:w-64" onChange={(e) => setSearchTerm(e.target.value)} />
          </div>
        </div>

        <div className="bg-white rounded-[2rem] shadow-sm border border-gray-100 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-100">
                  <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-widest text-center">Actions</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-widest">Property & Buyer</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-widest">UTR Number</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-widest text-center">Status</th>
                  <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-widest text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {filteredRecords.map((record, index) => (
                  <tr key={record.transaction_id} className="hover:bg-gray-50/50 transition">
                    <td className="px-6 py-4">
                        <div className="flex gap-3 justify-center">
                            <button onClick={() => copyToClipboard(record.transaction_ref)} className="text-gray-400 hover:text-blue-600 transition" title="Copy Ref">
                                <FaCopy />
                            </button>
                            <button onClick={() => downloadPDF(record)} className="text-gray-400 hover:text-red-600 transition" title="Download PDF">
                                <FaFilePdf />
                            </button>
                        </div>
                    </td>
                    <td className="px-6 py-4">
                      <p className="font-bold text-gray-800">{record.title}</p>
                      <div className="flex items-center gap-1 text-xs text-gray-500 mt-1">
                        <FaUser size={10} /> {record.buyer_name}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="font-mono text-sm bg-blue-50 text-blue-700 px-2 py-1 rounded">
                        {record.transaction_ref}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-center">
                        {record.admin_approval === 'approved' ? (
                          <span className="px-3 py-1 rounded-full text-[10px] font-bold bg-green-100 text-green-700 border border-green-200 uppercase">Approved</span>
                        ) : (
                          <span className="px-3 py-1 rounded-full text-[10px] font-bold bg-red-100 text-red-700 border border-red-200 uppercase">Rejected</span>
                        )}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <p className="font-black text-gray-900">₹{Number(record.price).toLocaleString()}</p>
                      <p className="text-[10px] text-gray-400 mt-1">{new Date(record.created_at).toLocaleDateString()}</p>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TransactionRecord;