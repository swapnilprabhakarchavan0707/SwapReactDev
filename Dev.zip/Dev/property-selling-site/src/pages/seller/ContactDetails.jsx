const ContactDetails = () => {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-6">Buyer Contact Details</h1>
      <div className="bg-white p-8 rounded-lg shadow">
        <p className="text-gray-600">View inquiries and contact information from interested buyers.</p>
      </div>
    </div>
  );
};

export default ContactDetails;