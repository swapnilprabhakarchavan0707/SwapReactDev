import React, { useState, useEffect } from 'react';
import { FaPlus, FaTrash, FaEdit, FaArrowLeft, FaUniversity } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';
import api from '../../services/api';
import { toast } from 'react-toastify';

const BankDetails = () => {
  const navigate = useNavigate();
  const [banks, setBanks] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchBanks = async () => {
    try {
      const res = await api.get('/banks/my-banks');
      setBanks(res.data);
      setLoading(false);
    } catch (err) {
      console.error(err);
      toast.error("Failed to fetch bank details");
      setLoading(false);
    }
  };

  useEffect(() => { fetchBanks(); }, []);

  const handleTogglePrimary = async (id) => {
    try {
      await api.put(`/banks/set-primary/${id}`);
      toast.success("Primary bank updated");
      fetchBanks();
    } catch (err) {
      toast.error("Failed to update primary bank");
    }
  };

  const handleDelete = async (id, isPrimary) => {
    if (isPrimary) {
      return toast.warning("Cannot delete a primary bank. Set another bank as primary first.");
    }

    if (window.confirm("Are you sure you want to remove this bank detail?")) {
      try {
        // Updated to match the backend route: /api/banks/:id
        await api.delete(`/banks/${id}`);
        toast.success("Bank detail removed");
        fetchBanks();
      } catch (err) {
        toast.error("Error deleting bank detail");
      }
    }
  };

  if (loading) return <div className="p-10 text-center">Loading Bank Details...</div>;

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-5xl mx-auto bg-white rounded-[30px] shadow-sm p-8 border border-gray-100">
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-4">
            <button onClick={() => navigate(-1)} className="p-2 bg-gray-100 rounded-full hover:bg-gray-200 transition">
              <FaArrowLeft />
            </button>
            <h1 className="text-2xl font-bold text-[#2D3748]">Bank Accounts</h1>
          </div>
          <button onClick={() => navigate('/seller/add-bank')} className="bg-[#10B981] text-white px-6 py-2 rounded-xl flex items-center gap-2 font-semibold shadow-md hover:bg-green-700 transition">
            <FaPlus /> Add Bank Detail
          </button>
        </div>

        {banks.length === 0 ? (
          <div className="text-center py-20 bg-gray-50 rounded-3xl border-2 border-dashed border-gray-200">
            <p className="text-gray-500">No bank accounts added yet.</p>
          </div>
        ) : (
          <div className="grid gap-4">
            {banks.map((bank) => (
              <div key={bank.bank_id} className={`p-6 rounded-2xl border flex justify-between items-center transition-all ${bank.is_primary ? 'border-blue-500 bg-blue-50/50 shadow-sm' : 'border-gray-100'}`}>
                <div className="flex items-center gap-4">
                  <div className={`p-3 rounded-xl ${bank.is_primary ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-400'}`}>
                    <FaUniversity className="text-2xl" />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-800">{bank.bank_name} - {bank.account_number}</h4>
                    <p className="text-sm text-gray-500">IFSC: {bank.ifsc_code} | Holder: {bank.account_holder_name}</p>
                    {bank.upi_id && <p className="text-xs text-blue-500 font-medium mt-1">UPI: {bank.upi_id}</p>}
                  </div>
                </div>
                
                <div className="flex items-center gap-6">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Primary</span>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input 
                        type="checkbox" 
                        className="sr-only peer" 
                        checked={bank.is_primary} 
                        onChange={() => handleTogglePrimary(bank.bank_id)} 
                        disabled={bank.is_primary} // Disable toggle if it's already primary
                      />
                      <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:bg-blue-600 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all"></div>
                    </label>
                  </div>

                  {/* Edit Button */}
                  <button 
                    onClick={() => navigate(`/seller/edit-bank/${bank.bank_id}`)}
                    className="p-2 text-blue-500 hover:bg-blue-50 rounded-lg transition"
                    title="Edit Bank Detail"
                  >
                    <FaEdit className="text-xl" />
                  </button>

                  {/* Delete Button */}
                  <button 
                    onClick={() => handleDelete(bank.bank_id, bank.is_primary)}
                    className={`p-2 rounded-lg transition ${bank.is_primary ? 'text-gray-300 cursor-not-allowed' : 'text-red-400 hover:bg-red-50'}`}
                    title={bank.is_primary ? "Cannot delete primary bank" : "Delete"}
                  >
                    <FaTrash className="text-lg" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default BankDetails;