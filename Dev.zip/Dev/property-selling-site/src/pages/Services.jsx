const Services = () => {
  const services = [
    {
      icon: '🏠',
      title: 'Property Listings',
      description: 'Browse through thousands of verified property listings across India',
      color: 'from-blue-500 to-blue-600'
    },
    {
      icon: '🔍',
      title: 'Advanced Search',
      description: 'Find your dream property with our powerful search filters and smart recommendations',
      color: 'from-green-500 to-green-600'
    },
    {
      icon: '💰',
      title: 'Secure Payments',
      description: 'Safe and secure payment processing with multiple payment options for all transactions',
      color: 'from-purple-500 to-purple-600'
    },
    {
      icon: '📱',
      title: 'Mobile Experience',
      description: 'Access properties on the go with our responsive mobile-friendly platform',
      color: 'from-pink-500 to-pink-600'
    },
    {
      icon: '👥',
      title: 'Expert Guidance',
      description: 'Get help from our property experts throughout the buying or selling process',
      color: 'from-yellow-500 to-yellow-600'
    },
    {
      icon: '📄',
      title: 'Legal Support',
      description: 'Comprehensive assistance with documentation, verification, and legal procedures',
      color: 'from-red-500 to-red-600'
    },
    {
      icon: '📊',
      title: 'Market Analysis',
      description: 'Get detailed market insights and property valuation reports',
      color: 'from-indigo-500 to-indigo-600'
    },
    {
      icon: '🎯',
      title: 'Investment Advisory',
      description: 'Expert advice on property investment opportunities and ROI analysis',
      color: 'from-teal-500 to-teal-600'
    },
    {
      icon: '🏗️',
      title: 'Property Management',
      description: 'Complete property management services for landlords and investors',
      color: 'from-orange-500 to-orange-600'
    }
  ];

  return (
    <div className="bg-gray-50">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-slate-700 via-slate-600 to-slate-800 text-white py-24">
        <div className="absolute inset-0 bg-black opacity-20"></div>
        <div className="container mx-auto px-4 text-center relative z-10">
          <h1 className="text-6xl font-bold mb-4">Our Services</h1>
          <p className="text-2xl text-gray-200 max-w-3xl mx-auto">
            We offer comprehensive services to make your property buying or selling experience smooth and hassle-free
          </p>
        </div>
      </div>

      {/* Services Grid */}
      <div className="container mx-auto px-4 py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div 
              key={index} 
              className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden transform hover:-translate-y-2"
            >
              <div className={`bg-gradient-to-r ${service.color} p-6 text-center`}>
                <div className="text-7xl mb-2">{service.icon}</div>
              </div>
              <div className="p-6">
                <h3 className="text-2xl font-bold mb-3 text-gray-800">{service.title}</h3>
                <p className="text-gray-600 leading-relaxed">{service.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Additional Info Section */}
      <div className="bg-white py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl font-bold text-center text-gray-800 mb-12">
              What Makes Our Services Special?
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-gradient-to-br from-blue-50 to-white p-8 rounded-2xl shadow-md">
                <h3 className="text-2xl font-bold text-blue-600 mb-4">🎯 Customer-Centric</h3>
                <p className="text-gray-700 leading-relaxed">
                  Every service is designed keeping your needs in mind. We prioritize your satisfaction above everything else.
                </p>
              </div>

              <div className="bg-gradient-to-br from-green-50 to-white p-8 rounded-2xl shadow-md">
                <h3 className="text-2xl font-bold text-green-600 mb-4">⚡ Quick & Efficient</h3>
                <p className="text-gray-700 leading-relaxed">
                  We value your time. Our streamlined processes ensure quick turnaround without compromising on quality.
                </p>
              </div>

              <div className="bg-gradient-to-br from-purple-50 to-white p-8 rounded-2xl shadow-md">
                <h3 className="text-2xl font-bold text-purple-600 mb-4">🔒 100% Secure</h3>
                <p className="text-gray-700 leading-relaxed">
                  Your data and transactions are protected with bank-grade security. Trust and transparency are our foundations.
                </p>
              </div>

              <div className="bg-gradient-to-br from-orange-50 to-white p-8 rounded-2xl shadow-md">
                <h3 className="text-2xl font-bold text-orange-600 mb-4">💼 Professional Team</h3>
                <p className="text-gray-700 leading-relaxed">
                  Our team of certified professionals brings years of experience to ensure the best outcomes for you.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Experience Our Services?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Let us help you find the perfect property or sell your existing one with ease
          </p>
          <a
            href="/contact"
            className="inline-block bg-white text-blue-600 px-10 py-4 rounded-full text-lg font-bold hover:bg-gray-100 transition shadow-xl"
          >
            Contact Us Today
          </a>
        </div>
      </div>
    </div>
  );
};

export default Services;