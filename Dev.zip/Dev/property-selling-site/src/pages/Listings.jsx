import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchProperties } from '../redux/slices/propertySlice';
import { toast } from 'react-toastify';
import PropertyCard from '../components/PropertyCard';

const Listings = () => {
  const dispatch = useDispatch();
  const { properties, loading } = useSelector((state) => state.property);

  const [filters, setFilters] = useState({
    city: '',
    property_type: '',
    min_price: '',
    max_price: ''
  });

  useEffect(() => {
    dispatch(fetchProperties({}));
  }, [dispatch]);

  const handleFilter = () => {
    const activeFilters = {};
    if (filters.city.trim()) activeFilters.city = filters.city.trim();
    if (filters.property_type) activeFilters.property_type = filters.property_type;
    if (filters.min_price) activeFilters.min_price = filters.min_price;
    if (filters.max_price) activeFilters.max_price = filters.max_price;

    dispatch(fetchProperties(activeFilters)).then((result) => {
      const count = result.payload?.length || 0;
      if (count === 0) toast.warning('No properties found for this criteria');
      else toast.success(`Showing ${count} properties`);
    });
  };

  const clearFilters = () => {
    setFilters({ city: '', property_type: '', min_price: '', max_price: '' });
    dispatch(fetchProperties({}));
    toast.info('Filters cleared');
  };

  const hasActiveFilters = filters.city || filters.property_type || filters.min_price || filters.max_price;

  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="bg-slate-800 text-white py-16 text-center">
        <h1 className="text-4xl font-bold mb-2">Find Your Perfect Home</h1>
        <p className="text-gray-400">Search through our exclusive property listings</p>
      </div>

      <div className="container mx-auto px-4 py-10">
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-10 border border-gray-100">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            {/* City */}
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Location</label>
              <input type="text" placeholder="Enter City" value={filters.city}
                onChange={(e) => setFilters({...filters, city: e.target.value})}
                className="w-full p-3 bg-gray-50 border rounded-xl focus:ring-2 focus:ring-blue-500" />
            </div>

            {/* Type */}
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Property Type</label>
              <select value={filters.property_type}
                onChange={(e) => setFilters({...filters, property_type: e.target.value})}
                className="w-full p-3 bg-gray-50 border rounded-xl focus:ring-2 focus:ring-blue-500">
                <option value="">All Types</option>
                <option value="1BHK">1BHK</option>
                <option value="2BHK">2BHK</option>
                <option value="3BHK">3BHK</option>
                <option value="Villa">Villa</option>
              </select>
            </div>

            {/* Price Box 1 (Your Budget) */}
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Your Budget (₹)</label>
              <input type="number" placeholder="Up to this amount" value={filters.min_price}
                onChange={(e) => setFilters({...filters, min_price: e.target.value})}
                className="w-full p-3 bg-gray-50 border rounded-xl focus:ring-2 focus:ring-blue-500" />
            </div>

            {/* Price Box 2 (Optional Max Range) */}
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase mb-2">To Price (Optional Range)</label>
              <input type="number" placeholder="Set Max Limit" value={filters.max_price}
                onChange={(e) => setFilters({...filters, max_price: e.target.value})}
                className="w-full p-3 bg-gray-50 border rounded-xl focus:ring-2 focus:ring-blue-500" />
            </div>
          </div>

          <div className="flex gap-3">
            <button onClick={handleFilter} className="flex-1 bg-blue-600 text-white py-3 rounded-xl font-bold hover:bg-blue-700 transition shadow-lg">
              Search Properties
            </button>
            <button onClick={clearFilters} disabled={!hasActiveFilters} className="px-6 bg-gray-100 text-gray-600 py-3 rounded-xl font-bold hover:bg-gray-200 disabled:opacity-50">
              Reset
            </button>
          </div>
        </div>

        {loading ? (
          <div className="text-center py-20 text-gray-400">Loading listings...</div>
        ) : properties.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-2xl border border-dashed">
            <p className="text-gray-500 font-medium">No properties match your current search.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {properties.map((property) => (
              <PropertyCard key={property.property_id} property={property} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Listings;