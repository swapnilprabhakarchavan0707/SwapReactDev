import { Link, useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { logout } from '../redux/slices/authSlice';
import { toast } from 'react-toastify';
import { useLocation } from 'react-router-dom';

// 1. Import the logo image
import websiteLogo from '../assets/favicon_io/logo.png';

const Navbar = () => {
  const { isAuthenticated, user } = useSelector((state) => state.auth);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const isDashboard = location.pathname.includes('dashboard');

  const handleLogout = () => {
    dispatch(logout());
    toast.success('Logged out successfully');
    navigate('/');
  };

  const getDashboardLink = () => {
    if (user?.role === 'admin') return '/admin/dashboard';
    if (user?.role === 'seller') return '/seller/dashboard';
    if (user?.role === 'buyer') return '/buyer/dashboard';
    return '/';
  };

  return (
    <nav className="bg-blue-600 text-white shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          
          {/* Logo and Brand Name Section */}
          <Link to="/" className="flex items-center space-x-2 text-2xl font-bold">
            <img 
              src={websiteLogo} 
              alt="Logo" 
              className="h-8 w-8 object-contain" 
            />
            <span> PropertyHub </span>
          </Link>

          {/* This section now strictly hides About and Services for any logged-in user */}
          <div className="hidden md:flex space-x-6">
            <Link to="/" className="hover:text-blue-200 transition">Home</Link>
            {!isAuthenticated && (
              <>
                <Link to="/about" className="hover:text-blue-200 transition">About</Link>
                <Link to="/services" className="hover:text-blue-200 transition">Services</Link>
              </>
            )}
            <Link to="/listings" className="hover:text-blue-200 transition">Listings</Link>
            <Link to="/contact" className="hover:text-blue-200 transition">Contact</Link>
          </div>

          <div className="flex items-center space-x-4">
            {isAuthenticated ? (
              <>
                <Link to={getDashboardLink()} className="hover:text-blue-200 transition" >
                  Dashboard
                </Link>
                <span className="text-sm hidden md:inline"> {user?.name} ({user?.role}) </span>
                <button onClick={handleLogout} className="bg-white text-blue-600 px-4 py-2 rounded-lg hover:bg-blue-50 transition font-semibold" >
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="hover:text-blue-200 transition"> Login </Link>
                <Link to="/register" className="bg-white text-blue-600 px-4 py-2 rounded-lg hover:bg-blue-50 transition font-semibold" >
                  Register
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;