import { Link, useNavigate } from 'react-router-dom';

const propertyImages = [
  'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=900',
  'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=900',
  'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=900',
  'https://images.unsplash.com/photo-1505691938895-1758d7feb511?w=900',
  'https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?w=900',
  'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=900',
  'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=900',
  'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=900',
  'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=900',
  'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=900',
];

const PropertyCard = ({ property, showWishlistButton = false, onWishlistClick }) => {
  const navigate = useNavigate(); // Hook for redirection

  // Logic: Use database image if available, else fallback to unsplash array
  const displayImage = property.image 
    ? `http://localhost:5000${property.image}` 
    : propertyImages[property.property_id % propertyImages.length];

  return (
    <Link
      to={`/property/${property.property_id}`}
      className="group bg-white rounded-2xl overflow-hidden shadow-premium hover:shadow-premium-xl transition-all duration-300 transform hover:-translate-y-3"
    >
      <div className="relative overflow-hidden h-64">
        <img
          src={displayImage}
          alt={property.title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          onError={(e) => { e.target.src = propertyImages[0]; }} // If upload image fails to load
        />
        
        <div className="absolute top-4 right-4 bg-blue-600 text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg">
          {property.property_type}
        </div>
        
        <div className="absolute top-4 left-4 bg-green-600 text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg capitalize">
          {property.status}
        </div>
        
        {showWishlistButton && (
          <button
            onClick={(e) => {
              e.preventDefault();
              // Redirect buyer directly to the purchase page
              navigate(`/buyer/purchase/${property.property_id}`);
              
              // Optional: Call parent click handler if you still need it for analytics/state
              if (onWishlistClick) onWishlistClick(property.property_id);
            }}
            className="absolute bottom-4 right-4 bg-white text-red-500 w-12 h-12 rounded-full flex items-center justify-center shadow-lg hover:bg-red-500 hover:text-white transition-all duration-300 z-10"
            title="Buy Now"
          >
            <span className="text-2xl">❤️</span>
          </button>
        )}
        
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
      </div>
      
      <div className="p-6">
        <h3 className="text-2xl font-bold mb-3 text-gray-800 group-hover:text-blue-600 transition line-clamp-2">
          {property.title}
        </h3>
        
        <p className="text-gray-600 mb-4 flex items-center text-lg">
          <span className="mr-2">📍</span>
          {property.address ? `${property.address}, ${property.city}` : property.city}
        </p>
        
        <div className="flex justify-between items-center pt-4 border-t border-gray-200">
          <div>
            <p className="text-sm text-gray-500 mb-1">Price</p>
            <p className="text-3xl font-bold text-blue-600">
              ₹{Number(property.price).toLocaleString()}
            </p>
          </div>
          <span className="text-blue-600 font-bold text-lg group-hover:underline flex items-center">
            View Details
            <span className="ml-2 transform group-hover:translate-x-2 transition-transform">→</span>
          </span>
        </div>
      </div>
    </Link>
  );
};

export default PropertyCard;