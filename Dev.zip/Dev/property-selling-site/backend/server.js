const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();
console.log('server.js: starting up...');

const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');
const propertyRoutes = require('./routes/propertyRoutes');
const transactionRoutes = require('./routes/transactionRoutes');
const messageRoutes = require('./routes/messageRoutes');
const adminRoutes = require('./routes/adminRoutes');
const contactRoutes = require('./routes/contactRoutes');
const bankRoutes = require('./routes/bankRoutes'); 

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

/**
 * NECESSARY CONFIGURATION:
 * Ensures the 'uploads' folder is served statically. 
 * This allows the buyer to see property images and the seller to see payment proofs.
 */
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Routes summaries console logging
function logStack(router, name) {
  if (!router || !router.stack) { console.log(name, 'no stack'); return; }
  router.stack.forEach((layer, idx) => {
    if (layer.route) {
        const methods = Object.keys(layer.route.methods).join(',').toUpperCase();
        console.log(`${name} [${methods}] -> ${layer.route.path}`);
    }
  });
}

console.log('--- router summaries ---');
logStack(authRoutes, 'authRoutes');
logStack(bankRoutes, 'bankRoutes');

// API Route mounting
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/properties', propertyRoutes);
app.use('/api/transactions', transactionRoutes);
app.use('/api/messages', messageRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/contact', contactRoutes);
app.use('/api/banks', bankRoutes);

// Global Error Handler
app.use((err, req, res, next) => {
  console.error('SERVER ERROR:', err.stack);
  res.status(500).json({ 
    message: 'Something went wrong!', 
    error: err.message 
  });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`Check API Status: http://localhost:${PORT}/api/properties`);
});