const express = require('express');
const router = express.Router();
const propertyController = require('../controllers/propertyController');
const { authenticateToken, authorizeRoles } = require('../middleware/auth');
const upload = require('../middleware/upload');

// Public routes
router.get('/', propertyController.getAllProperties);
router.get('/:id', propertyController.getPropertyById);

// Protected routes
router.post('/', 
  authenticateToken, 
  authorizeRoles('seller', 'admin'),
  upload.array('images', 10),
  propertyController.addProperty
);

router.put('/:id', 
  authenticateToken, 
  authorizeRoles('seller', 'admin'),
  upload.array('images', 10),
  propertyController.updateProperty
);

router.delete('/:id', 
  authenticateToken, 
  authorizeRoles('seller', 'admin'),
  propertyController.deleteProperty
);

router.get('/seller/my-properties', 
  authenticateToken, 
  authorizeRoles('seller', 'admin'),
  propertyController.getSellerProperties
);

module.exports = router;