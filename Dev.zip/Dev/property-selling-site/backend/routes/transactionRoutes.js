const express = require('express');
const router = express.Router();
const transactionController = require('../controllers/transactionController');
const { authenticateToken, authorizeRoles } = require('../middleware/auth');
const upload = require('../middleware/upload');

// ==========================================
// 1. PROPERTY & BUYER/SELLER TRANSACTIONS
// ==========================================

// Create Transaction (Buyer uploads proof)
router.post(
  '/', 
  authenticateToken, 
  authorizeRoles('buyer'), 
  upload.single('payment_proof'), 
  transactionController.createTransaction
);

// Get Buyer's specific transactions
router.get(
  '/buyer', 
  authenticateToken, 
  authorizeRoles('buyer'), 
  transactionController.getBuyerTransactions
);

// Get Seller's specific transactions (Admin included to see own sales)
router.get(
  '/seller', 
  authenticateToken, 
  authorizeRoles('seller', 'admin'), 
  transactionController.getSellerTransactions
);

// Admin view for ALL transactions (The Master List)
router.get(
  '/all', 
  authenticateToken, 
  authorizeRoles('admin'), 
  transactionController.getAllTransactions
);

// Master list of all seller records for the Admin dashboard toggle
router.get(
  '/admin/all-records', 
  authenticateToken, 
  authorizeRoles('admin'), 
  transactionController.getAllTransactions 
);

// Update Status (Approval/Rejection of a payment)
router.put(
  '/update-status',
  authenticateToken,
  authorizeRoles('seller', 'admin'),
  transactionController.updateTransactionStatus
);

// ==========================================
// 2. ADMIN BANK MANAGEMENT (Account Details)
// ==========================================

// Get all bank accounts for the Admin
router.get(
  '/admin/bank', 
  authenticateToken, 
  authorizeRoles('admin'), 
  transactionController.getAdminBankDetails
);

// Save a new bank account
router.post(
  '/admin/bank', 
  authenticateToken, 
  authorizeRoles('admin'), 
  transactionController.saveAdminBankDetails
);

/**
 * UPDATED ROUTE: Update existing bank details
 * This enables the 'Edit' functionality in the Admin UI
 */
router.put(
  '/admin/bank/:bank_id', 
  authenticateToken, 
  authorizeRoles('admin'), 
  transactionController.updateAdminBankDetails
);

// Delete a bank account
router.delete(
  '/admin/bank/:bank_id', 
  authenticateToken, 
  authorizeRoles('admin'), 
  transactionController.deleteAdminBankDetail
);

module.exports = router;