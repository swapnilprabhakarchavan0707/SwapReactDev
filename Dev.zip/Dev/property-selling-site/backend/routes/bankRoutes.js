const express = require('express');
const router = express.Router();
const bankController = require('../controllers/bankController');
const { authenticateToken } = require('../middleware/auth');
const db = require('../config/db'); // Moved up for cleaner access

// Apply authentication - The user must be logged in to manage/view bank info
router.use(authenticateToken);

// --- Existing Seller/Admin Logic ---
router.post('/add', bankController.addBank);
router.get('/my-banks', bankController.getSellerBanks);
router.put('/set-primary/:id', bankController.setPrimaryBank);

/**
 * UPDATED ROUTE:
 * Standardized the parameter to :propertyId.
 * This ensures that req.params.propertyId in your bankController.js 
 * receives the ID sent from the frontend.
 */
router.get('/purchase-info/:propertyId', bankController.getSellerPrimaryBankForBuyer);

// --- Edit Functionality ---

// Route to get a single bank's data for the Edit form
router.get('/:id', async (req, res) => {
    try {
        const userId = req.user.userId || req.user.id;
        const [banks] = await db.query(
            'SELECT * FROM seller_bank_details WHERE bank_id = ? AND seller_id = ?', 
            [req.params.id, userId]
        );
        
        if (banks.length === 0) {
            return res.status(404).json({ message: "Bank record not found" });
        }
        
        res.json(banks[0]);
    } catch (err) {
        console.error("Fetch Bank Error:", err);
        res.status(500).json({ message: "Error fetching bank" });
    }
});

// Route to update the bank details
router.put('/update/:id', async (req, res) => {
    const { bank_name, account_number, ifsc_code, account_holder_name, upi_id, is_primary } = req.body;
    const userId = req.user.userId || req.user.id;
    
    try {
        // If this update sets the bank to primary, unset others for this user first
        if (is_primary) {
            await db.query('UPDATE seller_bank_details SET is_primary = 0 WHERE seller_id = ?', [userId]);
        }

        const [result] = await db.query(
            'UPDATE seller_bank_details SET bank_name=?, account_number=?, ifsc_code=?, account_holder_name=?, upi_id=?, is_primary=? WHERE bank_id=? AND seller_id=?',
            [bank_name, account_number, ifsc_code, account_holder_name, upi_id, is_primary || 0, req.params.id, userId]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Bank record not found or unauthorized" });
        }

        res.json({ message: "Bank updated successfully" });
    } catch (err) {
        console.error("Update Bank Error:", err);
        res.status(500).json({ message: "Error updating bank" });
    }
});

// Added Delete route for completeness within this module
router.delete('/delete/:id', async (req, res) => {
    try {
        const userId = req.user.userId || req.user.id;
        await db.query('DELETE FROM seller_bank_details WHERE bank_id = ? AND seller_id = ?', [req.params.id, userId]);
        res.json({ message: "Bank account deleted successfully" });
    } catch (err) {
        res.status(500).json({ message: "Error deleting bank account" });
    }
});

module.exports = router;