const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { authenticateToken } = require('../middleware/auth');

// Send message
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { receiver_id, message } = req.body;
    const [result] = await db.query(
      'INSERT INTO messages (sender_id, receiver_id, message) VALUES (?, ?, ?)',
      [req.user.userId, receiver_id, message]
    );
    res.status(201).json({ message: 'Message sent successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to send message' });
  }
});

// Get messages
router.get('/', authenticateToken, async (req, res) => {
  try {
    const [messages] = await db.query(`
      SELECT m.*, sender.name as sender_name, receiver.name as receiver_name
      FROM messages m
      JOIN user sender ON m.sender_id = sender.user_id
      JOIN user receiver ON m.receiver_id = receiver.user_id
      WHERE m.sender_id = ? OR m.receiver_id = ?
      ORDER BY m.created_at DESC
    `, [req.user.userId, req.user.userId]);
    
    res.json({ messages });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch messages' });
  }
});

module.exports = router;