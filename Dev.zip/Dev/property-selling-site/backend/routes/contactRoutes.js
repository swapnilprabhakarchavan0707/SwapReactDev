const express = require('express');
const router = express.Router();
const db = require('../config/db');

// POST: Save message from Contact Page
router.post('/', async (req, res) => {
    try {
        const { name, email, phone, subject, message } = req.body;
        await db.query(
            'INSERT INTO contact_messages (name, email, phone, subject, message) VALUES (?, ?, ?, ?, ?)',
            [name, email, phone, subject, message]
        );
        res.status(201).json({ message: 'Saved successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// GET: Fetch all messages for the Admin Reviews page
router.get('/messages', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM contact_messages ORDER BY created_at DESC');
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// DELETE: Remove a message
router.delete('/:id', async (req, res) => {
    try {
        await db.query('DELETE FROM contact_messages WHERE id = ?', [req.params.id]);
        res.json({ message: 'Deleted' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;