const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { authenticateToken } = require('../middleware/auth');

// Get bank details (for sellers)
router.get('/bank-details', authenticateToken, async (req, res) => {
  try {
    const [details] = await db.query('SELECT * FROM seller_bank_details WHERE seller_id = ?', [req.user.userId]);
    res.json({ bankDetails: details[0] || null });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch bank details' });
  }
});

// Add/Update bank details
router.post('/bank-details', authenticateToken, async (req, res) => {
  try {
    const { bank_name, account_number, ifsc_code, account_holder_name, upi_id } = req.body;
    
    const [existing] = await db.query('SELECT * FROM seller_bank_details WHERE seller_id = ?', [req.user.userId]);
    
    if (existing.length > 0) {
      await db.query(
        'UPDATE seller_bank_details SET bank_name = ?, account_number = ?, ifsc_code = ?, account_holder_name = ?, upi_id = ? WHERE seller_id = ?',
        [bank_name, account_number, ifsc_code, account_holder_name, upi_id, req.user.userId]
      );
    } else {
      await db.query(
        'INSERT INTO seller_bank_details (seller_id, bank_name, account_number, ifsc_code, account_holder_name, upi_id) VALUES (?, ?, ?, ?, ?, ?)',
        [req.user.userId, bank_name, account_number, ifsc_code, account_holder_name, upi_id]
      );
    }
    
    res.json({ message: 'Bank details saved successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to save bank details' });
  }
});

module.exports = router;