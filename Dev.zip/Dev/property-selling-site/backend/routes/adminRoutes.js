const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const transactionController = require('../controllers/transactionController'); // Added to access bank logic
const { authenticateToken, authorizeRoles } = require('../middleware/auth');

const adminOnly = [authenticateToken, authorizeRoles('admin')];

// User Management
router.get('/users', adminOnly, adminController.getAllUsers);
router.post('/users', adminOnly, adminController.createUser);
router.put('/users/:id', adminOnly, adminController.updateUser);
router.delete('/users/:id', adminOnly, adminController.deleteUser);

// Payment Approvals
router.get('/payments/pending', adminOnly, adminController.getPendingPayments);
router.put('/payments/:paymentId/approve', adminOnly, adminController.approvePayment);

// Analytics
router.get('/reviews', adminOnly, adminController.getAllReviews);
router.get('/login-history', adminOnly, adminController.getLoginHistory);
router.delete('/login-history/:id', adminOnly, adminController.deleteLoginHistory);

// Admin Bank Details Management
router.get('/bank', adminOnly, transactionController.getAdminBankDetails);
router.post('/bank', adminOnly, transactionController.saveAdminBankDetails);
router.delete('/bank/:bank_id', adminOnly, transactionController.deleteAdminBankDetail);

module.exports = router;