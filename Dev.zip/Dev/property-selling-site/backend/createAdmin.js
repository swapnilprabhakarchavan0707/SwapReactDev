const bcrypt = require('bcrypt');

async function createAdminPassword() {
  const password = 'Admin@123'; // Change this to your desired password
  const hashedPassword = await bcrypt.hash(password, 10);
  console.log('Hashed Password:', hashedPassword);
  console.log('\nUse this in the SQL INSERT statement below');
}

createAdminPassword();