const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const db = require('../config/db');

// Register new user (Buyer or Seller)
exports.register = async (req, res) => {
  try {
    // UPDATED: Destructure 'role' from req.body
    const { name, email, password, phone, role } = req.body;

    // Check if user already exists
    const [existingUser] = await db.query('SELECT * FROM user WHERE email = ?', [email]);
    if (existingUser.length > 0) {
      return res.status(400).json({ message: 'Email already registered' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // UPDATED: Use the role from the request, default to 'buyer' if empty
    const userRole = role || 'buyer';

    // Insert new user
    const [result] = await db.query(
      'INSERT INTO user (name, email, password, phone, role, status) VALUES (?, ?, ?, ?, ?, ?)',
      [name, email, hashedPassword, phone, userRole, 'inactive']
    );

    res.status(201).json({
      message: 'Registration successful',
      userId: result.insertId
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ message: 'Registration failed', error: error.message });
  }
};

// Login
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const ip_address = req.ip;
    const user_agent = req.headers['user-agent'];

    // Find user
    const [users] = await db.query('SELECT * FROM user WHERE email = ?', [email]);
    
    if (users.length === 0) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    const user = users[0];

    // --- Updated Status Logic ---
    if (user.status === 'blocked') {
      return res.status(403).json({ message: 'Access denied. Your account has been blocked by the administrator.' });
    }

    // Verify password
    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    // If login is successful and status was "inactive", update it to "active"
    if (user.status === 'inactive') {
      await db.query('UPDATE user SET status = "active" WHERE user_id = ?', [user.user_id]);
    }

    // Log login history
    await db.query(
      'INSERT INTO login_history (user_id, ip_address, user_agent) VALUES (?, ?, ?)',
      [user.user_id, ip_address, user_agent]
    );

    // Generate JWT token
    const token = jwt.sign(
      { userId: user.user_id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({
      message: 'Login successful',
      token,
      user: {
        userId: user.user_id,
        name: user.name,
        email: user.email,
        role: user.role,
        phone: user.phone
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Login failed', error: error.message });
  }
};

// Get current user profile
exports.getProfile = async (req, res) => {
  try {
    const [users] = await db.query(
      'SELECT user_id, name, email, phone, role, status, created_at FROM user WHERE user_id = ?',
      [req.user.userId]
    );

    if (users.length === 0) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({ user: users[0] });
  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({ message: 'Failed to fetch profile', error: error.message });
  }
};