const db = require('../config/db');

// Get all properties
exports.getAllProperties = async (req, res) => {
  try {
    const { city, property_type, min_price, max_price, status } = req.query;
    let query = `
      SELECT p.*, u.name as seller_name, u.email as seller_email,
      (SELECT image_url FROM property_image WHERE property_id = p.property_id LIMIT 1) as image
      FROM properties p
      JOIN user u ON p.seller_id = u.user_id
      WHERE 1=1
    `;
    const params = [];
    if (city) { query += ' AND p.city = ?'; params.push(city); }
    if (property_type) { query += ' AND p.property_type = ?'; params.push(property_type); }
    if (min_price && max_price) {
      query += ' AND p.price BETWEEN ? AND ?'; params.push(min_price, max_price);
    } else if (min_price) {
      query += ' AND p.price >= ?'; params.push(min_price);
    } else if (max_price) {
      query += ' AND p.price <= ?'; params.push(max_price);
    }
    if (status && status !== 'all') {
      query += ' AND p.status = ?'; params.push(status);
    } else if (!status) {
      query += ' AND p.status = "available"';
    }
    query += ' ORDER BY p.created_at DESC';
    const [properties] = await db.query(query, params);
    if (req.user && req.user.userId) {
      await db.query(
        'INSERT INTO search_history (user_id, search_query, property_type, min_price, max_price, city) VALUES (?, ?, ?, ?, ?, ?)',
        [req.user.userId, req.query.search || null, property_type || null, min_price || null, max_price || null, city || null]
      );
    }
    res.json({ properties });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch properties', error: error.message });
  }
};

// Get property by ID
exports.getPropertyById = async (req, res) => {
  try {
    const { id } = req.params;
    const [properties] = await db.query(`
      SELECT p.*, u.name as seller_name, u.email as seller_email, u.phone as seller_phone
      FROM properties p
      JOIN user u ON p.seller_id = u.user_id
      WHERE p.property_id = ?
    `, [id]);
    if (properties.length === 0) return res.status(404).json({ message: 'Property not found' });
    const [images] = await db.query('SELECT * FROM property_image WHERE property_id = ?', [id]);
    const [reviews] = await db.query(`
      SELECT r.*, u.name as buyer_name
      FROM reviews r
      JOIN user u ON r.buyer_id = u.user_id
      WHERE r.property_id = ?
      ORDER BY r.created_at DESC
    `, [id]);
    res.json({ property: properties[0], images, reviews });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch property' });
  }
};

// Add new property
exports.addProperty = async (req, res) => {
  try {
    const { title, description, price, property_type, address, city } = req.body;
    const seller_id = req.user.role === 'admin' ? (req.body.seller_id || req.user.userId) : req.user.userId;
    const [result] = await db.query(
      'INSERT INTO properties (seller_id, title, description, price, property_type, address, city, status) VALUES (?, ?, ?, ?, ?, ?, ?, "available")',
      [seller_id, title, description, price, property_type, address, city]
    );
    if (req.files && req.files.length > 0) {
      const imageValues = req.files.map(file => [result.insertId, `/uploads/${file.filename}`]);
      await db.query('INSERT INTO property_image (property_id, image_url) VALUES ?', [imageValues]);
    }
    res.status(201).json({ message: 'Property added successfully', propertyId: result.insertId });
  } catch (error) {
    res.status(500).json({ message: 'Failed to add property' });
  }
};

// Update existing property
exports.updateProperty = async (req, res) => {
  try {
    const { id } = req.params;
    const { title, description, price, property_type, address, city, status } = req.body;
    await db.query(
      'UPDATE properties SET title = ?, description = ?, price = ?, property_type = ?, address = ?, city = ?, status = ? WHERE property_id = ?',
      [title, description, price, property_type, address, city, status, id]
    );
    if (req.files && req.files.length > 0) {
      await db.query('DELETE FROM property_image WHERE property_id = ?', [id]);
      const imageValues = req.files.map(file => [id, `/uploads/${file.filename}`]);
      await db.query('INSERT INTO property_image (property_id, image_url) VALUES ?', [imageValues]);
    }
    res.json({ message: 'Property updated successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to update property' });
  }
};

// Delete property
exports.deleteProperty = async (req, res) => {
  try {
    const { id } = req.params;
    await db.query('DELETE FROM property_image WHERE property_id = ?', [id]);
    await db.query('DELETE FROM properties WHERE property_id = ?', [id]);
    res.json({ message: 'Property deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to delete property' });
  }
};

// NECESSARY UPDATE: Structured response for Rohit Sharma's properties
exports.getSellerProperties = async (req, res) => {
  try {
    const seller_id = req.user.userId;
    const [properties] = await db.query(`
      SELECT p.*, 
      (SELECT image_url FROM property_image WHERE property_id = p.property_id LIMIT 1) as image
      FROM properties p WHERE p.seller_id = ? ORDER BY p.created_at DESC
    `, [seller_id]);
    res.json({ properties: properties || [] });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch seller properties' });
  }
};