const db = require('../config/db');

exports.addBank = async (req, res) => {
    const { bank_name, account_number, ifsc_code, account_holder_name, upi_id } = req.body;
    const seller_id = req.user.userId; 

    try {
        await db.query(
            'INSERT INTO seller_bank_details (seller_id, bank_name, account_number, ifsc_code, account_holder_name, upi_id) VALUES (?, ?, ?, ?, ?, ?)',
            [seller_id, bank_name, account_number, ifsc_code, account_holder_name, upi_id]
        );
        res.status(201).json({ message: "Bank details added successfully" });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.getSellerBanks = async (req, res) => {
    try {
        const [banks] = await db.query(
            'SELECT * FROM seller_bank_details WHERE seller_id = ? ORDER BY is_primary DESC', 
            [req.user.userId]
        );
        res.json(banks);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.setPrimaryBank = async (req, res) => {
    const { id } = req.params;
    const seller_id = req.user.userId;

    try {
        await db.query('UPDATE seller_bank_details SET is_primary = FALSE WHERE seller_id = ?', [seller_id]);
        await db.query('UPDATE seller_bank_details SET is_primary = TRUE WHERE bank_id = ? AND seller_id = ?', [id, seller_id]);
        res.json({ message: "Primary bank updated" });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.getSellerPrimaryBankForBuyer = async (req, res) => {
    const { propertyId } = req.params; 

    try {
        const query = `
            SELECT 
                p.property_id, p.title, p.price, p.property_type, p.status,
                u.name as seller_name, u.email as seller_email,
                b.bank_name, b.account_number, b.ifsc_code, b.account_holder_name, b.upi_id
            FROM properties p
            JOIN user u ON p.seller_id = u.user_id
            LEFT JOIN seller_bank_details b ON u.user_id = b.seller_id AND b.is_primary = 1
            WHERE p.property_id = ?
        `;

        const [results] = await db.query(query, [propertyId]);

        if (results.length === 0) {
            return res.status(404).json({ message: "Property not found" });
        }

        const data = results[0];
        res.json({
            property: {
                property_id: data.property_id,
                title: data.title,
                price: data.price,
                property_type: data.property_type,
                status: data.status,
                seller_name: data.seller_name,
                seller_email: data.seller_email
            },
            bank: data.bank_name ? {
                bank_name: data.bank_name,
                account_number: data.account_number,
                ifsc_code: data.ifsc_code,
                account_holder_name: data.account_holder_name,
                upi_id: data.upi_id
            } : null 
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "Server error" });
    }
};