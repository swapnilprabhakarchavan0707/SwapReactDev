const db = require('../config/db');
const bcrypt = require('bcrypt');

// User Management
exports.getAllUsers = async (req, res) => {
  try {
    // Changed DESC to ASC to show earlier created admins at the top
    const [users] = await db.query('SELECT user_id, name, email, phone, role, status, created_at FROM user ORDER BY created_at ASC');
    res.json({ users });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch users' });
  }
};

exports.createUser = async (req, res) => {
  try {
    const { name, email, password, phone, role } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    
    // Status is set to 'inactive' by default as per requirements
    const [result] = await db.query(
      'INSERT INTO user (name, email, password, phone, role, status) VALUES (?, ?, ?, ?, ?, ?)',
      [name, email, hashedPassword, phone, role, 'inactive']
    );
    
    await db.query(
      'INSERT INTO admin_logs (admin_id, action, target_type, target_id) VALUES (?, ?, ?, ?)',
      [req.user.userId, 'CREATE_USER', 'user', result.insertId]
    );
    
    res.status(201).json({ message: 'User created successfully', userId: result.insertId });
  } catch (error) {
    res.status(500).json({ message: 'Failed to create user' });
  }
};

exports.updateUser = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, email, phone, role, status, password } = req.body;
    
    // Dynamic query to handle optional password updates
    let query = 'UPDATE user SET name = ?, email = ?, phone = ?, role = ?, status = ?';
    let params = [name, email, phone, role, status];

    if (password && password.trim() !== "") {
      const hashedPassword = await bcrypt.hash(password, 10);
      query += ', password = ?';
      params.push(hashedPassword);
    }

    query += ' WHERE user_id = ?';
    params.push(id);

    await db.query(query, params);
    
    await db.query(
      'INSERT INTO admin_logs (admin_id, action, target_type, target_id) VALUES (?, ?, ?, ?)',
      [req.user.userId, 'UPDATE_USER', 'user', id]
    );
    
    res.json({ message: 'User updated successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to update user' });
  }
};

exports.deleteUser = async (req, res) => {
  try {
    const { id } = req.params;
    
    await db.query('DELETE FROM user WHERE user_id = ?', [id]);
    
    await db.query(
      'INSERT INTO admin_logs (admin_id, action, target_type, target_id) VALUES (?, ?, ?, ?)',
      [req.user.userId, 'DELETE_USER', 'user', id]
    );
    
    res.json({ message: 'User deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to delete user' });
  }
};

// Payment Approvals
exports.getPendingPayments = async (req, res) => {
  try {
    const [payments] = await db.query(`
      SELECT pd.*, t.*, p.title, buyer.name as buyer_name, seller.name as seller_name
      FROM payment_details pd
      JOIN property_transaction t ON pd.transaction_id = t.transaction_id
      JOIN properties p ON t.property_id = p.property_id
      JOIN user buyer ON t.buyer_id = buyer.user_id
      JOIN user seller ON t.seller_id = seller.user_id
      WHERE pd.admin_approval = 'pending'
      ORDER BY pd.created_at DESC
    `);
    
    res.json({ payments });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch pending payments' });
  }
};

exports.approvePayment = async (req, res) => {
  try {
    const { paymentId } = req.params;
    const { approve } = req.body; 
    
    const status = approve ? 'approved' : 'rejected';
    
    await db.query('UPDATE payment_details SET admin_approval = ? WHERE payment_id = ?', [status, paymentId]);
    
    if (approve) {
      const [payments] = await db.query(`
        SELECT pd.*, t.property_id, t.seller_id, t.buyer_id, t.price
        FROM payment_details pd
        JOIN property_transaction t ON pd.transaction_id = t.transaction_id
        WHERE pd.payment_id = ?
      `, [paymentId]);
      
      if (payments.length > 0) {
        const payment = payments[0];
        await db.query('UPDATE property_transaction SET payment_status = ? WHERE transaction_id = ?', 
          ['completed', payment.transaction_id]);
        await db.query('UPDATE properties SET status = ? WHERE property_id = ?', 
          ['sold', payment.property_id]);
        await db.query(
          'INSERT INTO buyer_history (buyer_id, property_id, seller_id, purchase_price, purchase_date, payment_mode) VALUES (?, ?, ?, ?, CURDATE(), ?)',
          [payment.buyer_id, payment.property_id, payment.seller_id, payment.price, payment.payment_mode]
        );
      }
    }
    
    await db.query(
      'INSERT INTO admin_logs (admin_id, action, target_type, target_id) VALUES (?, ?, ?, ?)',
      [req.user.userId, approve ? 'APPROVE_PAYMENT' : 'REJECT_PAYMENT', 'transaction', paymentId]
    );
    
    res.json({ message: `Payment ${status} successfully` });
  } catch (error) {
    res.status(500).json({ message: 'Failed to process payment approval' });
  }
};

// Reviews
exports.getAllReviews = async (req, res) => {
  try {
    const [reviews] = await db.query(`
      SELECT r.*, p.title, u.name as buyer_name
      FROM reviews r
      JOIN properties p ON r.property_id = p.property_id
      JOIN user u ON r.buyer_id = u.user_id
      ORDER BY r.created_at DESC
    `);
    res.json({ reviews });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch reviews' });
  }
};

// Login History
exports.getLoginHistory = async (req, res) => {
  try {
    const { userId } = req.query;
    let query = `
      SELECT lh.*, u.name, u.email, u.role
      FROM login_history lh
      JOIN user u ON lh.user_id = u.user_id
    `;
    const params = [];
    if (userId) {
      query += ' WHERE lh.user_id = ?';
      params.push(userId);
    }
    query += ' ORDER BY lh.login_time DESC LIMIT 100';
    const [history] = await db.query(query, params);
    res.json({ history });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch login history' });
  }
};

exports.deleteLoginHistory = async (req, res) => {
  try {
    const { id } = req.params;
    await db.query('DELETE FROM login_history WHERE login_id = ?', [id]);
    res.json({ message: 'Login history deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to delete login history' });
  }
};