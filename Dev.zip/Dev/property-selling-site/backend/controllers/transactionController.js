const db = require('../config/db');

// --- 1. PROPERTY & BUYER/SELLER TRANSACTION LOGIC ---

exports.createTransaction = async (req, res) => {
  try {
    const property_id = req.body.property_id || req.body.id;
    const { transaction_ref, payment_mode } = req.body;
    const payment_proof = req.file ? req.file.path : null; 
    
    const buyer_id = req.user.userId || req.user.id;

    const [properties] = await db.query('SELECT * FROM properties WHERE property_id = ?', [property_id]);
    if (properties.length === 0) {
      return res.status(404).json({ message: 'Property not found' });
    }
    
    const property = properties[0];
    
    const [transactionResult] = await db.query(
      'INSERT INTO property_transaction (property_id, buyer_id, seller_id, price, payment_status) VALUES (?, ?, ?, ?, ?)',
      [property_id, buyer_id, property.seller_id, property.price, 'pending']
    );
    
    const transactionId = transactionResult.insertId;

    await db.query(
      'INSERT INTO payment_details (transaction_id, transaction_ref, payment_mode, payment_proof, admin_approval) VALUES (?, ?, ?, ?, ?)',
      [transactionId, transaction_ref, payment_mode || 'bank_transfer', payment_proof, 'pending']
    );
    
    res.status(201).json({ 
      message: 'Transaction created successfully', 
      transactionId: transactionId 
    });
  } catch (error) {
    console.error("Transaction Error:", error);
    res.status(500).json({ message: 'Failed to create transaction', error: error.message });
  }
};

exports.updateTransactionStatus = async (req, res) => {
  const { transaction_id, status } = req.body; 

  try {
    await db.query(
      'UPDATE payment_details SET admin_approval = ? WHERE transaction_id = ?',
      [status, transaction_id]
    );

    const paymentStatus = status === 'approved' ? 'completed' : 'failed';

    await db.query(
      'UPDATE property_transaction SET payment_status = ? WHERE transaction_id = ?',
      [paymentStatus, transaction_id]
    );

    res.json({ message: `Transaction has been ${status} successfully.` });
  } catch (error) {
    console.error("Status Update Error:", error);
    res.status(500).json({ message: 'Failed to update transaction status' });
  }
};

exports.getBuyerTransactions = async (req, res) => {
  try {
    const buyer_id = req.user.userId || req.user.id;
    const [transactions] = await db.query(`
      SELECT 
        t.*, p.title, p.address, pd.admin_approval, pd.transaction_ref, 
        pd.payment_mode, pd.payment_proof, u.name AS seller_name,
        u.email AS seller_email, u.phone AS seller_phone
      FROM property_transaction t
      JOIN properties p ON t.property_id = p.property_id
      JOIN user u ON t.seller_id = u.user_id 
      LEFT JOIN payment_details pd ON t.transaction_id = pd.transaction_id
      WHERE t.buyer_id = ?
      ORDER BY t.created_at DESC
    `, [buyer_id]);
    
    res.json({ transactions });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch buyer transactions' });
  }
};

exports.getSellerTransactions = async (req, res) => {
  try {
    const seller_id = req.user.userId || req.user.id;
    const [transactions] = await db.query(`
      SELECT 
        t.*, p.title, u.name as buyer_name, u.email as buyer_email,
        u.phone as buyer_phone, pd.admin_approval, pd.transaction_ref, 
        pd.payment_proof, pd.payment_mode
      FROM property_transaction t
      JOIN properties p ON t.property_id = p.property_id
      JOIN user u ON t.buyer_id = u.user_id
      LEFT JOIN payment_details pd ON t.transaction_id = pd.transaction_id
      WHERE t.seller_id = ?
      ORDER BY t.created_at DESC
    `, [seller_id]);
    
    res.json({ transactions });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch transactions' });
  }
};

exports.getAllTransactions = async (req, res) => {
  try {
    const [transactions] = await db.query(`
      SELECT t.*, p.title, 
             buyer.name as buyer_name, seller.name as seller_name,
             pd.admin_approval, pd.transaction_ref, pd.payment_mode, pd.payment_proof
      FROM property_transaction t
      JOIN properties p ON t.property_id = p.property_id
      JOIN user buyer ON t.buyer_id = buyer.user_id
      JOIN user seller ON t.seller_id = seller.user_id
      LEFT JOIN payment_details pd ON t.transaction_id = pd.transaction_id
      ORDER BY t.created_at DESC
    `);
    
    res.json({ transactions });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch transactions' });
  }
};

// --- 2. ADMIN BANK DETAILS (seller_bank_details table) ---

exports.getAdminBankDetails = async (req, res) => {
  try {
    const admin_id = req.user.userId || req.user.id;
    const [details] = await db.query(
      'SELECT * FROM seller_bank_details WHERE seller_id = ?', 
      [admin_id]
    );
    res.json({ bankDetails: details });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch bank details' });
  }
};

exports.saveAdminBankDetails = async (req, res) => {
  try {
    const admin_id = req.user.userId || req.user.id;
    const { bank_name, account_number, ifsc_code, account_holder_name, upi_id, is_primary } = req.body;

    if (is_primary) {
      await db.query('UPDATE seller_bank_details SET is_primary = 0 WHERE seller_id = ?', [admin_id]);
    }

    await db.query(
      `INSERT INTO seller_bank_details 
       (seller_id, bank_name, account_number, ifsc_code, account_holder_name, upi_id, is_primary) 
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [admin_id, bank_name, account_number, ifsc_code, account_holder_name, upi_id, is_primary || 0]
    );

    res.json({ message: 'Bank account added successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to save bank details' });
  }
};

exports.updateAdminBankDetails = async (req, res) => {
  try {
    const admin_id = req.user.userId || req.user.id;
    const { bank_id } = req.params;
    const { bank_name, account_number, ifsc_code, account_holder_name, upi_id, is_primary } = req.body;

    // If setting this one to primary, unset all other accounts for this user
    if (is_primary) {
      await db.query('UPDATE seller_bank_details SET is_primary = 0 WHERE seller_id = ?', [admin_id]);
    }

    const [result] = await db.query(
      `UPDATE seller_bank_details 
       SET bank_name = ?, account_number = ?, ifsc_code = ?, account_holder_name = ?, upi_id = ?, is_primary = ?
       WHERE bank_id = ? AND seller_id = ?`,
      [bank_name, account_number, ifsc_code, account_holder_name, upi_id, is_primary, bank_id, admin_id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Bank details not found or unauthorized' });
    }

    res.json({ message: 'Bank details updated successfully' });
  } catch (error) {
    console.error("Update Bank Error:", error);
    res.status(500).json({ message: 'Failed to update bank details' });
  }
};

exports.deleteAdminBankDetail = async (req, res) => {
  try {
    const admin_id = req.user.userId || req.user.id;
    const { bank_id } = req.params;
    
    // Safety check to ensure the admin owns the record they are deleting
    const [result] = await db.query(
      'DELETE FROM seller_bank_details WHERE bank_id = ? AND seller_id = ?', 
      [bank_id, admin_id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Bank account not found' });
    }

    res.json({ message: 'Bank account deleted successfully' });
  } catch (error) {
    console.error("Delete Bank Error:", error);
    res.status(500).json({ message: 'Delete failed' });
  }
};